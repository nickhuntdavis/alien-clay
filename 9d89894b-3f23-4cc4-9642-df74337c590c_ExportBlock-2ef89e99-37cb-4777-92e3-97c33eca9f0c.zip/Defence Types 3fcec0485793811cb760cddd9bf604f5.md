# Defence Types

A reference for the five core defensive mechanics in Spawn Prawn. Each defence changes a different combat outcome: soften physical impact, absorb damage with a regenerating barrier, reduce physical damage with finite armour layers, retaliate on contact, or avoid eligible attacks.

<aside>
🧭

**Design baseline:** these are distinct mechanics, not universal damage-type immunities. Resolve the actual attack component—direct damage, status application, persistent hazard, impulse/control, or area coverage—and keep the result readable at combat speed.

</aside>

## Core defence roster

- **Squishy / Absorption:** proportionally reduces qualifying physical damage and may soften physical impulse.
- **Membrane:** a separate regenerating shield pool; Force is resisted, while Static can supercharge or rapidly recharge it.
- **Shell:** finite, non-regenerating armour layers that reduce qualifying physical damage; Acid erodes layers and heavy Force can knock one loose.
- **Thorns:** returns damage after qualifying melee/contact hits; does not reduce incoming damage.
- **Dodge:** avoids eligible hits through movement/timing; it does not erase existing statuses or persistent hazards.

## Shared rules

- **Force is physical damage.** Squishy and Shell therefore affect Force damage when its attack component qualifies as physical; they differ in how they mitigate it.
- **Squishy uses proportional reduction.** It softens qualifying physical damage rather than subtracting a fixed amount.
- **Shell uses finite layers.** Layers provide a fixed reduction against qualifying physical hits and are permanently lost when shed during an encounter. Exact values remain for tuning.
- **Membrane is its own pool.** It absorbs eligible direct damage before health. Force is less effective against the membrane than ordinary eligible damage; Static can accelerate recovery or temporarily supercharge it, depending on the attack/ability rule chosen.
- **Damage blocking is not status immunity.** Prevent an attached status only when its application hit is prevented or a specific resistance says so.
- **Persistent hazards resolve separately.** Dodging a projectile does not grant immunity to an Acid pool, burning zone, or other hazard entered later.
- **Thorns triggers once per qualifying connected contact hit.** It does not mitigate that hit; a clean Dodge means no contact and no retaliation.
- **Area attacks use their actual coverage.** Dodging the core may still leave the creature inside the edge of a blast or wave.
- **Keep counterplay visible.** Shield recharge, Shell loss, Thorns retaliation, and successful/failed Dodge outcomes need clear cues.

## Individual defence pages

The pages below use the same design-reference approach as the damage-type pages: identity, core mechanics, scaling, strengths and weaknesses, interactions, and explicit limits.

[Squishy / Absorption](Defence%20Types/Squishy%20Absorption%203fcec048579381289641ea8167c16783.md)

[Membrane](Defence%20Types/Membrane%203fcec048579381279220db6f543708d2.md)

[Shell](Defence%20Types/Shell%203fcec0485793810d8b73dd186679dd8c.md)

[Thorns](Defence%20Types/Thorns%203fcec04857938166a84bcecc153b4ef8.md)

[Dodge](Defence%20Types/Dodge%203fcec048579381769cb7f9807feaf744.md)