# Fire

**Ignite. Burn. Spread—when the setup allows it.**

Fire is the ignition and exposure type. It applies Burn, creates short-lived burning zones, and can propagate through explicitly compatible setups. It should not become the strongest generic damage-over-time type or make every surface explode.

## Visual language

**Orange; unmistakable flames, flickering tongues, embers, short-lived burning patches, and an orange UI ring for Burn duration.** Use a crisp ignition whoosh and crackle. Show the edge and lifetime of burning zones clearly; propagation should be a visible, bounded event rather than a surprise chain.

## Core mechanics

- **Burn:** Repeated hits or continued exposure may build a capped Burn state. Make the threshold and duration legible; ordinary Burn should not outclass Acid's defence erosion or Blood's wound payoff.
- **Ignition:** At a defined threshold, an explicitly designed attack can trigger an ignition payoff. Not every Fire hit causes a burst.
- **Burning zones:** Some attacks create short-lived, bounded zones. A zone can affect a target that enters it later; dodging the original projectile does not grant immunity to the zone.
- **Propagation:** Fire spreads only through explicitly compatible targets, patches, or named reactions. Limit each event to one clear payoff and prevent reaction-created fire from retriggering itself.

## Strengths and limits

**Strong against:** exposed targets, prepared flammable setups, and enemies that remain in a visible burning zone.

**Weak against:** dispersed or mobile targets, enemies that escape exposure, and targets with explicit Fire resistance. Squishy and Shell do not inherently resist heat or Burn.

## Defence interactions

- **Squishy / Absorption:** Does not inherently resist heat or Burning. It can reduce only a separately tagged qualifying physical component of a Fire attack.
- **Membrane:** Absorbs eligible direct damage before health. It does not automatically prevent Burn or protect against later exposure to a burning zone.
- **Shell:** Reduces only qualifying physical hit components. It does not inherently resist heat or Burn.
- **Thorns:** A qualifying melee/contact hit triggers one retaliation after it connects. A burning zone or non-contact heat effect does not automatically trigger Thorns.
- **Dodge:** Can avoid an eligible Fire hit. It does not undo existing Burn or make the target immune to a separate burning zone.

## Pair reactions

All reactions are proposed for playtesting. Each needs a clear cue and must not retrigger itself.

- **Force + Fire — Flashover:** A Force weapon hits a burning target; a small tongue of flame jumps to one nearby target. No uncontrolled fire chain.
- **Acid + Fire — Premature Evaporation:** A Fire attack hits an Acid-coated target; the coating is consumed in a modest close-range burst. This is not an automatic explosion from every Acid puddle.
- **Static + Fire — Arc Flash:** A Static attack hits a burning target; one short arc jumps to the nearest other eligible enemy. Do not stack extra Burn, stun, and multi-jump chaining.
- **Mucus + Fire — Flammable Mucus:** A Fire attack ignites a visible Mucus patch; the patch burns briefly as a small temporary no-go zone, then is consumed. No lingering Mucus slow after ignition.
- **Blood + Fire — Cauterise:** A Fire attack hits a bleeding target; it consumes the Bleed for an immediate burst. Do not add a fresh Burn by default.
- **Soul + Fire — Spectral Combustion:** A Soul/Fire combo hits a burning, Soul-marked target; it consumes the mark in a short spectral burst. Trigger on a hit, not only on defeat.

## Design boundaries

Fire owns ignition, Burn, and bounded propagation. Acid erodes defences; Blood owns wounds; Mucus owns sticky control; Static owns chains and interruption; Force owns impact; Soul owns essence. Keep the visual cue immediate and the spread limit obvious.