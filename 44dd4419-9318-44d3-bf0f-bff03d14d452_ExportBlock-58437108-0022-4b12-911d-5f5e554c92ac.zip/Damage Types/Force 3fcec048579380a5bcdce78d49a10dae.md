# Force

**Hit hard. Build momentum. Break poise. Send enemies flying.**

Force is the burst-and-displacement type. It delivers immediate physical impact, builds poise pressure, and changes enemy positions. It wins through a decisive hit or collision, not through sustained damage.

## Visual language

**White and pale grey; hard-edged impact rings, compressed silhouettes, sharp directional motion lines, and brief screen-space jolts.** Use a heavy, blunt hit sound and a clear travel direction. The cue should feel solid and physical, not soft or spectral like Soul. Keep impact flashes brief so the player can read the next attack.

## Core mechanics

- **Impact:** High immediate physical damage, usually delivered by punches, headbutts, tackles, slams, or heavy strikes.
- **Poise pressure:** Repeated qualifying hits build pressure toward a brief stagger or interrupt. Use thresholds and diminishing returns on elites; avoid stun-lock.
- **Displacement:** Strong hits push or launch targets. A wall or hazard only adds a payoff when a real collision occurs.
- **Momentum:** Attacker mass and actual speed at contact may increase impact. Keep the benefit readable and avoid requiring the player to calculate it.
- **Shockwave:** Only attacks explicitly designed to convert excess impact into an area effect create one; it is not automatic on every poise break.

## Strengths and limits

**Strong against:** unarmoured targets, vulnerable poise, clustered enemies, and targets near walls or hazards.

**Weak against:** Shell layers, Membranes, anchored targets, evasive enemies, and targets with little physical substance. Force is not a reliable sustained-damage tool.

## Defence interactions

- **Squishy / Absorption:** Reduces qualifying blunt impact damage and may reduce impulse, knockback, and collision effects. It does not make the target immune to Force.
- **Membrane:** Force is inefficient against the shield: it drains the pool less efficiently and causes less knockback while the shield is active.
- **Shell:** Qualifying physical hits are reduced by remaining layers. A sufficiently heavy Force impact can knock one layer loose; the lost layer stays gone for the encounter.
- **Thorns:** A qualifying melee/contact hit triggers one retaliation after the hit connects. Thorns does not reduce the incoming hit. A clean Dodge means no contact and no retaliation.
- **Dodge:** Can avoid an eligible Force hit. If the target avoids the strike, attached impact/status effects do not apply; a target still inside an attack's actual AoE may be hit by its edge.

## Pair reactions

All reactions are proposed for playtesting. Each needs a clear cue and must not retrigger itself.

- **Force + Acid — Corrosive Splash:** A Force strike hits an Acid-coated target; a small amount of Acid splashes onto nearby enemies. Spread the setup, not a second large damage burst.
- **Force + Static — Shocking Impact:** A named Force/Static weapon combo lands; a short local electrical burst occurs around the impact. It does not chain.
- **Force + Mucus — Snot Rocket:** A Force attack hits a Mucus-stuck enemy; it launches the enemy in the hit direction and leaves one small sticky patch on landing. No extra stun or bonus-damage layer.
- **Force + Blood — Blood Pressure:** A Force finisher hits a bleeding target; the wound bursts for one small area hit. Do not add another Bleed stack or a large pool.
- **Force + Soul — Soul Purpose:** A Force hit connects with a Soul-marked target; the hit breaks the mark and briefly exposes the target to the next Soul hit. No fragment or pickup system.
- **Force + Fire — Flashover:** A Force weapon hits a burning target; a small tongue of flame jumps to one nearby target. No uncontrolled chain.

## Design boundaries

Force owns physical impact, poise pressure, and displacement. It does not own electrical chaining, defence erosion, sticky control, wound economy, essence damage, or general burning. Resolve the actual attack component: physical damage, impulse, status application, and area coverage can each interact with defences differently.