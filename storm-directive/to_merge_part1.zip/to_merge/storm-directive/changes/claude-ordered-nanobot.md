# Change fragment: claude/ordered-nanobot

## 2026-10-20 Ordered Online drawn as a synthetic nanobot (not shipped)
- Systems: samplelooks, orderedlook (new)
- Files: orderedlook.js (new), samplelooks.js (old Ordered Online head and tail removed, header comment), index.html, ARCHITECTURE.md
- What: Ordered Online's body (in a run, on the sample card, in the Field Guide and pause portrait) is a machine (SAMPLES.md 5, decision 43): a segmented glossy silver shell with a seam down the head, panel gaps, a lens and a cyan status light on a jointed servo midpiece (amber after a glitch, red when hit); a tail of rigid links whose wave moves in exact steps (4 poses a beat, about 11 steps a second); a two-frame twitch every 2.5 to 6 s; on a corner the head leads past its heading, holds 0.12 s, then corrects in one step. Its Mucus trail gets a glossy gel band and a specular line on top. All cosmetic: hitbox, swim physics, kit, passive, Feat and trail rules unchanged.
- Save data: none.
- Hooks: none in shared files; replaces SL_HEAD/SL_TAIL.ordered, adds SL_UNDER.ordered, sets SL.ordered.beat 0.45 (visual beat only), wraps f10Draw.
- Risk: none to balance. The trail sheen is drawn in v10Draw (over zones, under you); a branch that edits SL_HEAD.ordered in samplelooks.js would be overridden by orderedlook.js.
