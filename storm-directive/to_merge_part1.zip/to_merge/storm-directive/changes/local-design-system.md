# local design-system session (shares the claude/consciousness-gifts checkout)

## 2026-10-20 HUD, loot cards and boss card through the kit
- Systems: ui, uikit, hud
- Files: uikit.js, ui.js, index.html, ARCHITECTURE.md
- What: the HUD overlay (uiHud: uiHudKey, uiWeaponSlotClass/Inner, uiRewindButton, uiToast, uiSystemMessage) and the boss introduction (uiBossIntro, uiBossCard) moved out of index.html into builders; uikit.js fills #hud and #bossIntro as it loads, with every element id unchanged. Loot and weapon-upgrade card bodies use uiLootCard, the section labels uiLootSection. Screens pixel-identical; 17 tests pass (quick, hudshot3, bossshot, bosstest, rewindtest, loottest, mythtest, overtest, tapcycle, introtest, rivintro, newtut, tuttest, settabs, autotest, putest, wup1test).
- Save data: none
- Hooks: none (uikit.js now fills #hud and #bossIntro at load)
- Risk: low. Anything that adds elements to #hud must run after uikit.js loads (all current code does: it runs from ui.js init or later).

## 2026-10-20 Last lists and chip rows through the kit
- Systems: ui, uikit
- Files: ui.js, aimat.js, junk.js, samplelooks.js
- What: the Combos, Pairings and Damage-type synergies lists and the Autorun directive chips (ui.js), the whose-mess chips (aimat.js), the Junk DNA list (junk.js) and the Field Guide samples list (samplelooks.js) now use uiList/uiChips/uiChip/uiHint. No hand-written .list or .chips markup is left in web/js. Screens pixel-identical; 16 tests pass (adds aimowntest, pairtest).
- Save data: none
- Hooks: none
- Risk: low.

## 2026-10-20 Every menu panel through the kit
- Systems: ui, uikit
- Files: uikit.js, ui.js, loadout.js
- What: the 21 panels that are filled over several statements now open and close with uiPanelOpen()/uiPanelClose(), and the settings row uses uiPanel; no hand-written .sec markup is left in ui.js or loadout.js. Screens pixel-identical; the same 14 tests pass.
- Save data: none
- Hooks: none
- Risk: low.

## 2026-10-20 UI builders from the design system
- Systems: ui, uikit
- Files: uikit.js (new), ui.js, loadout.js, pinhide.js, samples10.js, inspect.js, v10.js, sandbox.js, index.html, ARCHITECTURE.md
- What: menus now build their HTML through one builder per design-system component (uikit.js, 15 builders, 203 call sites). Output is the same elements and classes as before: all 35 screen captures (portrait and landscape) are pixel-identical and quick, settabs, setshot, loottest, loadouttest, inspecttest, porttest, logtest, stpanel, glosstest, youshot2, overtest, finaletest and sbtest pass. Not converted at the time: 21 split panels (since done, above), 5 lists and 1 chip row with classes glued to expressions, and the HUD, loot cards and boss card (built as DOM or static HTML in index.html).
- Save data: none
- Hooks: none (index.html: uikit.js after settings.js)
- Risk: low; markup is unchanged. Anything new that builds a menu should use the builders.

## 2026-10-20 Design-token layer in style.css
- Systems: ui
- Files: style.css, look10.js (comment), data.js (comment)
- What: one :root block of tokens named like the Figma variables (colour, space, radius, surfaces); the three old :root blocks folded in, older names (--xw, --dim, --r, --line ...) kept as aliases; 308 declarations that a later rule with the same selector always overrides removed; 121 hex colours swapped for tokens. Screens pixel-identical. 229 one-off colours left as they are (no matching token).
- Save data: none
- Hooks: none
- Risk: low.
