# Change fragment: local copy (Downloads), 20 Oct 2026. Not a git branch; fold into CHANGELOG.md when this work reaches a branch.

## 2026-10-20 Range stops growing with level (not shipped)
- Systems: engine
- Files: game.js
- What: long-range weapons stay at REACH_START (300, about a phone's half-width) at every level instead of growing 30 a level to their full range (Acid Spit was 300 / 390 / 440 by tier), so kills happen on screen. Range upgrade cards still multiply it.
- Save data: none.
- Hooks: none (one line in computeStats).
- Risk: every long-range weapon is weaker from tier 2; balance shifts for all samples (bot sim below is noisy at 4 runs a sample).

## 2026-10-20 Sample 9 (proposed): sample, three weapons, 45 branch cards, tuning (not shipped)
- Systems: acro, acrosample, samples, weapons24, feats10
- Files: acro.js (new), acrosample.js (new), index.html
- What: Sample 9 (Acid / Fire, all text TODO_COPY): its three weapons (acro_cap, acro_spray, acro_spark) join the roster with their branches; the sample itself (passive, Unique Feat, exclusive gift X9, unlock, body, cosmetic lurch). Tuned after bot sims: Feat penalty -25% for 4 s (was -50% for 6 s); cap 34, spray 8 per pellet, beam 4 per tick. Spec: redesign docs/SAMPLE_9_ACRO.md.
- Save data: META.s10.acro (unlock), META.s10runs.acro.
- Hooks: none in shared files; wraps wupStats, wupFire, wupDmgMul, wupHit, wupKill, wupTick, hurtPlayer, s10Hit, s10DmgMul, s10Tick, sampleLook.
- Risk: roster is 27 weapons; any sample can draft the three. TODO_COPY strings show in the UI until the copy is written.

## 2026-10-20 Van de Graaff Feat (not shipped)
- Systems: feats
- Files: feats10.js
- What: the re-gifted Van de Graaff (FEATS.md F6) is built and in the starting pool; Lv 5 fork text TODO_COPY.
- Save data: none.
- Hooks: none (f10Tick and f10Draw call its own functions in feats10.js).
- Risk: one more Static Feat in the draft.

## 2026-10-20 Beams pass Charge arcs every 3rd hit (not shipped)
- Systems: combat
- Files: fight.js; redesign docs/COMBAT_MATRIX.md (decision 45, sections 4 and 11.5 Charge rows), tables/*.csv (re-exported)
- What: a Beam's Static hits pass Charge arcs on only every 3rd hit, counted per weapon (fightBeamArcOk). Red Flagship at level 1 (weapon arena, XP frozen): 65 to 75 damage a second before, 61 to 72 after; its arc share 19-22% to 14-15%. Every other attack type unchanged.
- Save data: none.
- Hooks: none (one helper in fight.js, called from fightStatus).
- Risk: Red Flagship's Static-arc branch cards and combos (Static Cling, Crossing the Streams) see a third of the arcs from beams.

## 2026-10-20 Beam base damage 3.5 to 3 (not shipped)
- Systems: v10, weapons
- Files: v10.js (V10_ATK.beam.base.dmg)
- What: the matrix beams' base damage drops 15%. Live, that is only Red Flagship (Soulmate Signal and Sample 9's beam set their own). Red Flagship at level 1, XP frozen: 61 / 72 damage a second (standing / circling) after decision 45, 56 / 62 after this; field: Standard Issue 47 / 50, Nervous Wreck 45 / 78, Acid Spit 33 / 40.
- Save data: none.
- Hooks: none.
- Risk: the archived matrix beams (Lab Bench, Switched at Birth targets) drop too.

## 2026-10-20 Chain jumps don't pass Charge arcs (not shipped)
- Systems: combat, engine
- Files: fight.js (fightArcOk, was fightBeamArcOk), game.js (doChain tags jumps chainHop); redesign docs/COMBAT_MATRIX.md (decision 46, Charge rows), tables/*.csv
- What: only a chaining attack's first hit passes Charge arcs on; its jumps (doChain and the chaining modifier) don't. Unwanted Contact at level 1, XP frozen: 96 / 86 damage a second (standing / circling) before, 84 / 81 after; its arc share 30% to 17%.
- Save data: none.
- Hooks: none new (doChain adds a src flag).
- Risk: Static Cling combos and Unwanted Contact branch cards that lean on arcs from jumps lose some of them.

## 2026-10-20 Unwanted Contact damage 13 to 11 (not shipped)
- Systems: weapons
- Files: sigweap.js (sigReg 'tesla' base override; the archived Static Cling def keeps 13)
- What: Unwanted Contact at level 1, XP frozen: 84 / 81 damage a second (standing / circling) after decision 46, 70 / 69 after this. Field in the same test: Red Flagship 60 / 61, Nervous Wreck 43 / 77, Acid Spit 56 / 43, Standard Issue 41 / 46.
- Save data: none.
- Hooks: none.
- Risk: Redtail's starter is weaker; Redtail averaged wave 10.0 in the last big sim, before these Static changes.

## 2026-10-20 Autorun KITE keeps your reach; targets count from their edge (not shipped)
- Systems: autorun, engine
- Files: autorun.js (arKite, new arReach), game.js (acquire and acquireMany range checks)
- What: KITE's band (240 / 360 / 450) now scales to your longest weapon reach (65% / 85% / 95%, never more than before); with nothing within 420 it closes in on the nearest enemy (that branch could never run before); with a boss alive it closes until the boss's edge is in reach. acquire and acquireMany count an enemy in range when its edge is (range + its radius); shots, beams and chains already hit on contact with the edge, so a picked big target is hittable. Bot, Baseline, 12 instrumented mortal runs each: average wave 11.1 to 12.9, worst run 5 to 9, boss in reach 51% to 62% of boss-fight time; damage share on the boss unchanged (24% to 25%: the aim still picks the escorts).
- Save data: none.
- Hooks: none.
- Risk: player autorun KITE plays closer with short-range weapons; every weapon can now pick big targets slightly further away (by their radius).

## 2026-10-20 Default aim prefers the boss (not shipped)
- Systems: autorun, engine, ui
- Files: autorun.js (aimDir), game.js (targetScore 'bossfirst'), ui.js (both aim menus set w.dirSet)
- What: a slot on its default NEAREST aim (no tie-breaker, never set in an aim menu) aims at a boss in reach before its escorts while a boss is alive. Bot, Baseline, 12 instrumented runs: damage on the boss 25% to 44%, boss fights won in 50 s on average (was 135 s), but average wave 12.9 to 11.3 (7 of 12 died at the wave-10 boss, to its own attacks: death stare, contact, bullets). Net: shorter boss fights, no gain in how far the bot gets.
- Save data: none (w.dirSet is per run).
- Hooks: none new.
- Risk: players on default aim now shoot the boss over nearer escorts; choosing any aim (even NEAREST) turns it off for that slot.

## 2026-10-20 Autorun bullet dodging looks further ahead (not shipped)
- Systems: autorun, engine
- Files: game.js (autoSteer: STEER_BUL, bullet radius 300 to 420)
- What: each candidate heading checks bullets at four moments (0.1, 0.225, 0.45, 0.675 s) instead of two, and sees bullets from 420 instead of 300. Bot, Baseline, 12 instrumented runs: average wave 11.8 (spread 3.6), against 11.3 with boss-first aim alone: no measurable change.
- Save data: none.
- Hooks: none.
- Risk: slightly more steering work per frame (4 checks per bullet per heading, more bullets in range).
