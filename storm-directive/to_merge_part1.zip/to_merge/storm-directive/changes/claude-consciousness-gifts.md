## 2026-10-20 X5, X7, X8 to full spec; five old test failures fixed
- Systems: feats10, tests
- Files: gifts10.js, tests/featstest.js, drafttest.js, samplestest.js, ufeatstest.js, v10test.js
- What: X5 also slips chargers' and bosses' aimed wind-ups, and the attack it dodged hits its own side (areas when they go off, dashes for 1.6 s). X7's copies fire your real first weapon (an echo slot at half damage, three quarters with Muscle Memory) and count towards the 8-pet cap (wraps sigweap.js sigPetCount). X8 also clears a Complement Protein's mark (G.complT). Tests: featstest's pool is 16 (Van de Graaff), with tests for Van de Graaff, X9 and the three spec details; drafttest accepts the tabbed tier screen a lone weapon opens; samplestest, ufeatstest and v10test allow the PROPOSED Sample 9.
- Save data: none.
- Hooks: none in shared files (adds a sigPetCount wrap).
- Risk: X7 fires the weapon from the copy by moving the player for one call; a weapon with side effects on the player (a lunge) could misbehave. Supersedes the "Simplified against the spec" note below.

## 2026-10-20 Doc names for two Feats, Feat-line ownership, run.sh on macOS
- Systems: feats10, card voice, tests
- Files: feats10.js, giftvoice.js (regenerated), tests/tools/copy/giftvoice.py, tests/tools/copy/cardvoice.py, tests/run.sh, CLAUDE.md
- What: Comfort Eating is More! again and Clean Plate is COME BACK HERE (decision 45). Feat card lines are owned by the docs via giftvoice.py, the sheet keeps every other card (decision 46). run.sh runs on a Mac: no `timeout` needed, and it shims playwright-core into out/.pw when `playwright` is missing (nothing installed).
- Save data: none (Feat ids unchanged).
- Hooks: none.
- Risk: anything keyed on the two old titles (none found outside the generated tables).

## 2026-10-20 Consciousness gift lines, exclusive gifts and six new Feats
- Systems: feats10, card voice, samples10
- Files: gifts10.js (new), giftvoice.js (new, generated), tests/tools/copy/giftvoice.py (new), samples10.js, index.html, tests/featstest.js, ARCHITECTURE.md
- What: every Feat card now shows the approved per-sample gift line from the redesign docs (GIFT_LINES.md, FEATS.md 3), replacing the sheet's Feat lines; Alpha's Red Flagship Lv 3 lines and the Alpha, Beta and Ordered Online sample lines (Ordered Online is now a synthetic nanobot: origin and Scientist line) follow the docs. The eight sample-exclusive gifts X1 to X8 are drafted for their own sample only, and THIS WAY, Capacitation, Bombardier Beetle, Spinnbarkeit, Wandering Womb and Ear Candling join the later unlocks. Level 5 forks for all fourteen were written in code (the docs list level 3 only). The card text for the fourteen (does lines, fork names and descriptions, pops) was written by Claude and approved as written by the user on 20 Oct.
- Simplified against the spec: X5 dodges only the telegraphs newfoes.js exposes (G.nfBurst, wind-ups) and the dodged attack does not hit its own side; X7's copies fire bolts of the first weapon's damage type at half damage (at most two copies; they do not count towards the pet cap); X8 reacts to statuses only, not marks.
- Save data: none.
- Hooks: none in shared files (wraps f10Hurt, f10Kill, f10Tick, f10Draw, arGoal, sampleLook).
- Risk: Card_Copy_Draft_All.xlsx's Feat lines are now overridden: rerunning cardvoice.py alone no longer changes Feat lines (run giftvoice.py). Balance of the new gifts is untested by sims. Ordered Online's body still draws the old frosted look (samplelooks.js): the nanobot look is follow-on work.
