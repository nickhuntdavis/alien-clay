# MERGE_INSTRUCTIONS.md: merge this folder into `main` of nickhuntdavis/alien-clay

You are an agent merging local work into GitHub `main`. Follow the steps in order. Expected time: 30 to 60 minutes, most of it the test suite.

## What this folder is

- It comes as two zips, `to_merge_part1.zip` (all code, docs and this kit, plus some art) and `to_merge_part2.zip` (the rest of `storm-directive/art/`). Unzip both into the same place: each holds a `to_merge/` folder and they merge into one.

- Every file the local sessions changed or added (except the art left out below), in the local copy (`~/Downloads/ac/alien-clay-main`), compared with the 08:26 download of `main` (20 Oct 2026). The snapshot was taken at 15:12. Paths mirror the repo root (`storm-directive/...`, `redesign docs/...`). No file was deleted.
- These are the **local versions**, not merged ones. Never copy them straight over `main`: 25 of them were also changed on `main` (`_merge_kit/also_changed_upstream.txt`), and a plain copy would undo that work.
- `_merge_kit/base/`: the 08:26 version of those 25 files, the common ancestor for a three-way merge.
- `_merge_kit/changed_files.txt`: all 184 files in this folder.
- `_merge_kit/card_renames_by_weapon.json`: the cards that were renamed, by weapon key, as `{ old name: new name }`.
- What each piece of work does: `storm-directive/changes/*.md` (five fragments: card copy, Sample 9 and tuning, consciousness gifts, design system, Ordered Online nanobot). Read their **Systems** and **Hooks** lines first; they name the spots where branches collide.

## Steps

1. **Clone `main` and check it.**
   ```bash
   git clone https://github.com/nickhuntdavis/alien-clay.git /tmp/ac && git -C /tmp/ac log -1 --oneline
   ```
   When this kit was made, `main` was at `c89814f`. If it has moved, the merge still works the same way; just expect more conflicts.

2. **Build a three-way merge in git**, so git resolves everything that changed on one side only:
   ```bash
   K=~/Downloads/ac/to_merge
   git -C /tmp/ac checkout -b local-base c89814f~0
   ```
   Then on `local-base`, overwrite each of the 25 overlapping files with `_merge_kit/base/<path>` and commit ("base"). Then branch `local` from it, copy in all 188 files from this folder (`rsync -a --exclude _merge_kit --exclude MERGE_INSTRUCTIONS.md $K/ /tmp/ac/`), and commit ("local"). Then:
   ```bash
   git -C /tmp/ac checkout main && git -C /tmp/ac merge local
   ```
   Because `local-base` is `main` with the 25 shared files reset to the base, git only sees our edits on those 25 and merges them against `main`'s edits. Every other file applies cleanly.

3. **Resolve the conflicts using the rulings already made** (below). Any other conflict: keep both sides' behaviour. Card **text** comes from the local side, code and hooks from `main`.

4. **Fix old card names in `main`'s code.** `main` added code that matches cards by their old names. For every pair in `card_renames_by_weapon.json`, grep the merged tree for the old name in quotes and, where it refers to that weapon's card, change it to the new name. Known spots: `fitcheck.js` FIT_BRANCH and FIT_TEXT. Note that `Return to Sender` maps to a different new name per weapon. `tests/tools/guide.js` prose can keep the old names (already flagged as stale).

5. **Run the tests** (about 8 minutes). Each test drives the game in headless Chromium via Playwright. In the cloud container, `run.sh` works as is (repo `CLAUDE.md` > Tests: install nothing). Only on a Mac where `node -e "require('playwright')"` fails, install `playwright@1.61.0` (its Chromium matches the one cached in `~/Library/Caches/ms-playwright`) and point `NODE_PATH` at it:
   ```bash
   npm --prefix /tmp/pw install playwright@1.61.0 && NODE_PATH=/tmp/pw/node_modules bash /tmp/ac/storm-directive/tests/run.sh
   ```
   The local `run.sh` was already made macOS-safe. If it still says `timeout: command not found`, put a shim on `PATH` that drops its first argument. Also run the tests that `run.sh` leaves out: `switchtest fittest wstest rewarduitest`.

6. **Compare the failures with the known list** (below). Any failure not on it was caused by the merge. Fix it before committing.

7. **Fold the change logs** (repo `CLAUDE.md` > Change log). Move every entry from `storm-directive/changes/local-*.md` and `claude-*.md` into `CHANGELOG.md` under a new top heading `## Unreleased (merged to main without a build): <date> local work (...)`, each as `### Folded from <fragment name>: <entry title>`. Then delete those fragments. Also update `ARCHITECTURE.md`'s script-order line to match `web/index.html`. No version bump and no APK build: version numbers change only in the ship command.

8. **Commit and push**, after the user confirms the push:
   ```bash
   git -C /tmp/ac push origin main
   ```
   The GitHub account `nickhdnoa` has read access only. Pushing needs `nickhuntdavis` (`gh auth login`) or collaborator access.

## Rulings already made (apply them, don't ask again)

| Conflict | Ruling |
|---|---|
| Branch card text (`wup2.js`, `wup3.js`, `wup4.js`, all `lv3`/`lv6` `desc`) | Local text. Keep `main`'s new calls inside `apply`: `w2SnotFeed(w)`, `w2PinBase(w)`, `w3TypeFeed(w)` (add `w3TypeFeed(w);` as the first statement of each lv3 `apply` that has it on `main`). |
| `fitcheck.js` FIT_BRANCH | `main`'s logic (switched-type cases such as `w.def.elem === 'ice'`) with the local names: Elbow Room, Trigger Happy, Leapfrog, Mouthful, Revolving Door. FIT_TEXT keys: `Return to Sender` becomes `Revolving Door` (v_soul_proj), `Afterglow` becomes `Still Buzzing` (s_tesla). |
| Van de Graaff built twice (local `feats10.js` id `van_de_graaff`; `main` `feats9.js` id `vandegraaff`) | Keep the local one (it has the user's copy). Delete `main`'s `feat({ id: 'vandegraaff' ... })` block in `feats9.js`, leaving a one-line comment, and change `featstest.js`'s `vandegraaff` entry to `van_de_graaff` with enemy bullets aimed at the player in `pre`. |
| `web/index.html` script order | Keep both: local scripts (`acro.js`, `cardvoice.js`, `giftvoice.js`, `acrosample.js`, `uikit.js`, `orderedlook.js`, `gifts10.js`) and `main`'s (`whisper.js`, `director.js`, `race15.js`, `rewardui.js`, `buildpanel.js`, `feats9.js`, `v9back.js`). Where both added scripts at the same spot, put the local ones first. |
| Voice canon (`voice_and_tone.md` rule 6, `VOICE_GUIDE.md` 2, `CONSCIOUSNESS.md` shared rules) | **The user ruled on 20 Oct.** The consciousness is a soul not yet born (not the sperm, not the swimmer's own head). It speaks **mostly as "we"**, like a coach or a passenger (one team); **"you" when it blames or accuses**; **"me"/"I" only rarely, when it is being nakedly selfish**. Write that into all three docs. Remove the "addresses the sperm as you" line in `VOICE_GUIDE.md` 2. |
| `ARCHITECTURE.md` system table | Keep both sides' rows. |
| `NOTES.md` open-thread bullets | Keep both sides' bullets. |
| `ui.js`, `style.css` (local design-system kit vs `main`'s reward cards, Build panel and whispers) | Not merged yet, so expect conflicts. Keep the local kit's builders and tokens, and keep every `main` hook call (`rwCls`, `rwIcoHtml`, `rwFitHtml`, `rwPicked`, `bpHtml`, `wsTake`, `box.dataset.who`). The card quip line (`.cquip`, from `cardVoice`) must still show on loot cards. |
| `android/`, `release/SpawnPrawn.apk`, `meta.js` APP_VERSION | `main`'s. The local side did not change them. |

## Known test failures (they fail before the merge too)

- weapons24test: "roster ; pool 27" (Sample 9 adds 3 weapons).
- samplestest, ufeatstest, featstest: Sample 9 (`acro`, `acro_x9`) has no test entries yet. The consciousness-gifts session says it fixed five old failures, so some of these may now pass.
- wup5test: Dinner Time (Sister Cousin Lv 6) "no dinner_ready".
- v10test: samples screen.
- drafttest: "wup screen: loot LEVEL UP" (also fails on `main`).
- rewarduitest (not in `run.sh`): UPGRADE cards have no type or icon (also fails on `main`).

## Left out on purpose (the user ruled: keep them off GitHub)

- `storm-directive/art.zip` (15 MB) and `storm-directive/art/_kit/*.psd` (three Photoshop templates, 41 MB). They are not in this folder. Do not add them, and add both to `.gitignore` (`storm-directive/art.zip`, `storm-directive/art/**/*.psd`) in the merge commit.

## Still open after the merge (report, don't fix)

- 532 of the 4,770 card voice lines in `cardvoice.js` say "you". Some fit the new rule (blame) and some don't. The fix goes in `Card_Copy_Draft_All.xlsx` (then rerun `tests/tools/copy/cardvoice.py`), not in the generated JS.
- Sessions may still be editing `~/Downloads/ac/alien-clay-main` after 15:12. Before pushing, diff that folder against this one and bring in anything newer.
