# Combat System Matrix

A shared map of how damage types, mechanics, interactions, and defences fit together. Use this to expose overlap, missing counters, unclear rules, and combinations that may be too strong.

<aside>
🧩

**Design status:** entries are proposals until explicitly accepted and tested. A listed interaction means it deserves a defined rule; it does not automatically mean it succeeds or grants immunity.

</aside>

## How to use this workspace

1. **Mechanics & Statuses** records individual effects and rules, such as Burn, Ignition, Hemorrhage, displacement, fear, and resource drain.
2. **Defences & Traits** records defensive layers and innate properties, such as Armour, Shield, Dodge, Squish, Fearless, and Bloodless.
3. **Combat Interactions** records each relationship between types, mechanics, and defences: synergy, counter, bypass, conversion, immunity, or another explicit interaction.

## Design principles

- Separate attack avoidance, damage reduction, force absorption, status resistance, and immunity.
- A defence should state exactly what it affects and what it does not affect.
- Damage types should have distinct jobs: Force impacts and displaces; Acid erodes defences; Static chains and interrupts; Mucus controls movement; Blood exploits wounds and extraction; Soul attacks essence and nonphysical resources; Fire escalates through heat, ignition, and propagation.
- Treat uncertain rules as **Proposed**, not as established facts.
- Every one of the 21 unique pairs among Force, Acid, Static, Mucus, Blood, Soul, and Fire must have at least one designed reaction. A designed reaction is not an automatic proc: define a readable trigger such as a weapon combo, a marked target, or a visible world condition. Two types merely hitting the same enemy is not sufficient.

## Review checklist

- Does every mechanic have a clear purpose and counterplay?
- Does every defence protect against a defined set of outcomes?
- Are any two types solving the same combat problem?
- Are there mechanics with no meaningful counter?
- Can any combination create an unavoidable loop, infinite chain, or excessive damage multiplier?
- Are environmental conditions and exceptions explicit?

## Provisional coverage matrix

This summary uses the same labels as the detailed matrix: **S** = signature/strong interaction; **C** = conditional or ability-tag dependent; **—** = no special interaction intended; **?** = unresolved. A dash is not immunity. These are the **six core defences** only; Fire Resistance is an optional trait, not a core defence.

Read coverage by **damage component**, not damage-type name alone: direct hit, status application, persistent hazard, or control/impulse. Blocking a hit does not automatically remove an effect already applied or a hazard already created. Attack and status tags determine which rule applies.

| Damage type | Armour | Shield | Dodge | Squish | Fearless | Bloodless |
| --- | --- | --- | --- | --- | --- | --- |
| Force | Reduces tagged direct damage; no default bypass | Blocks a covered hit when facing it and capacity remains | Avoids eligible attacks during the dodge window | Reduces knockback, collision impulse and Force stagger | Only relevant if the attack is also Fear-tagged | No effect |
| Acid | Reduces tagged direct damage; Corrosion can erode Armour | May block delivery; Corrosion applies only if its application condition is met | Avoids eligible attacks, not existing pools or Corrosion | No effect on Acid or Corrosion | Only relevant if Fear-tagged | No effect |
| Static | Reduces only Armour-tagged damage; no default bypass | May block the carrier hit; Charge/arc uses its own application rule | Can avoid telegraphed hits, not automatically erase active hazards | No effect on Charge/interruption unless impulse is explicit | Only relevant if Fear-tagged | No effect |
| Mucus | No default protection from movement control | May block a hit, but does not remove a patch already placed | May avoid delivery; existing patches can still constrain movement | No effect on sticking or movement restriction | Only relevant if Fear-tagged | No effect |
| Blood | Reduces tagged direct damage, not automatically Bleed/Extraction | May block delivery; does not remove an existing wound | May avoid eligible carrier attacks, not existing wounds/pools | No effect unless impulse is explicit | Only relevant if Fear-tagged | Blocks blood-dependent Bleed/Extraction, not direct Blood damage |
| Soul | Explicit essence-tagged components may bypass Armour only | Blocks covered physical carriers; direct essence effects need a specific rule | Avoids eligible attacks, not an existing Soul Mark | No effect unless impulse is explicit | Resists Fear-tagged effects only | No effect |
| Fire | Reduces tagged direct damage, not automatically Burning | May block delivery; Burn applies only if the attack successfully applies it | Avoids eligible attacks; leaving a zone does not undo Burning | No effect on heat/Burning unless impulse is explicit | Only relevant if Fear-tagged | No effect |

## Databases

[Mechanics & Statuses](Combat%20System%20Matrix/Mechanics%20&%20Statuses%204285ff3837ab4701ba2af959c5454167.csv)

[Defences & Traits](Combat%20System%20Matrix/Defences%20&%20Traits%201aca8f05c13340ed9e9f9be458b9618a.csv)

[Combat Interactions](Combat%20System%20Matrix/Combat%20Interactions%200f167a3f197240a18c3c985dad1272c9.csv)

## Interactive database views

[Untitled](Combat%20System%20Matrix/Untitled%208201dc765ed44d108ab6579da201e446.csv)

[Untitled](Combat%20System%20Matrix/Untitled%20d41600edaf464a45bc746a96f27b53bc.csv)

[Untitled](Combat%20System%20Matrix/Untitled%204df2ed703a99498fbd57a95cd40e9241.csv)

[Master Combat-System Matrix — Draft](Combat%20System%20Matrix/Master%20Combat-System%20Matrix%20%E2%80%94%20Draft%203fcec048579381d38978f2de228ceb1d.md)

## Combat Matrix Review — 17 Oct 2026

**Review outcome:** The seven damage-type identities are sufficiently distinct to continue content design, but the matrix is not yet complete enough for numerical balancing. This section records design decisions and recommended dispositions. Existing interaction rows should be moved from Proposed only after their individual rules are reconciled with this review.

### Coverage gaps to close

1. **Damage components:** distinguish direct hit damage, damage over time, status buildup, displacement/impact, interruption, resource drain, and maximum-health/revival effects. One attack may carry multiple components; each component needs its own defence tags.
2. **Defensive layers:** separate Dodge (avoid the hit), Shield (block/absorb a delivered attack), Armour (mitigate tagged damage), Squish (absorb impulse), resistance (reduce a tagged status/damage component), and immunity (prevent a specific effect).
3. **Missing traits to consider:** Cleanse/Purge (remove existing statuses), Insulation (reduce Static buildup or chain eligibility), Soul Ward (resist essence-targeting effects), and Regeneration (recover health over time). These are proposals, not yet approved additions.
4. **Status counterplay:** use the detailed matrix's current vocabulary: Poise Pressure, Knockback, Corrosion, Acid Pool, Charge, Snared, Bleed, Extraction, Soul Mark, Fear, and Burning. Define how each shipped status expires, decays, stacks, or can be removed; clarify whether resistance reduces buildup, duration, or severity. Avoid treating older labels such as Hemorrhage, Adhesion, or Soul Fracture as separate statuses unless they are deliberately reinstated.
5. **Attack delivery and persistence:** a shield or dodge may stop an incoming attack but should not automatically erase an already-created hazard or a status already applied. Persistent zones need their own counterplay.
6. **Unrepresented matchups:** explicitly decide Shield vs Acid corrosion, Shield vs Mucus contact effects, Shield vs Blood status delivery, Armour vs Static damage, and Dodge vs area/persistent attacks. Avoid blanket assumptions based only on damage-type names.
7. **Recovery and economy:** define how Acid's regeneration suppression interacts with healing, how Blood extraction sustain is capped, and whether Soul's maximum-health/revival effects can be cleansed or restored.
8. **Reaction coverage and trigger discipline:** all 21 unique damage-type pairs need a designed reaction, documented in the [Master Combat-System Matrix — Draft](Combat%20System%20Matrix/Master%20Combat-System%20Matrix%20%E2%80%94%20Draft%203fcec048579381d38978f2de228ceb1d.md). Each reaction still needs an explicit, visible trigger; co-applying two types to one enemy does not automatically trigger it. Use material/condition tags where relevant, and keep each payoff brief and readable for a fast-paced game.

### Review dispositions for baseline mechanics and defence interactions

The list below covers general mechanics/defence rules, not the 21 damage-type pair reactions. Those pair reactions are tracked separately in the linked Master Combat-System Matrix and remain proposed until playtested.

**Accept as baseline rules**

- **Acid erodes Armour:** corrosion buildup reduces armour effectiveness; specify buildup, decay, and repair. It does not inherently suppress healing or bypass unrelated defences.
- **Fearless resists Fear:** only effects tagged Fear are resisted. Fearless is not blanket protection from Soul.
- **Bloodless prevents bleeding / blocks Exsanguination:** only blood-dependent wound, extraction, and resource effects are prevented; direct Blood damage can still work.
- **Squish absorbs Force impact:** reduce impulse/displacement and possibly stagger; do not silently equate this with all-purpose health damage reduction.
- **Directional Shield blocks covered attacks:** facing and capacity matter. Secondary effects are blocked only when the delivery is blocked; persistent hazards need separate rules.
- **Dodge avoids eligible telegraphed attacks:** this is avoidance, not mitigation. It does not erase existing statuses or persistent zones.
- **Static chains through conductive targets:** use valid conductive links plus range/chain limits; its identity is conductivity and interruption.
- **Ignition propagates to susceptible targets:** propagation only on a defined ignition event, with range, susceptibility, and a per-chain re-ignition lockout.
- **Fire Resistance counters Burn:** separate reduced Burn damage, reduced buildup, delayed Ignition, and full immunity.
- **Extinguishing effects suppress Fire:** define what removes existing Burn and what merely stops further buildup or propagation; allow explicit exceptions for special fire. Extinguishing is an environmental or ability rule, not a Water damage type.
- **Armour and Burn are separate layers:** ordinary Armour only mitigates damage components tagged for it; Burn uses heat/status resistance unless a specific armour trait says otherwise.
- **Essence-targeting Soul bypasses ordinary Armour:** this is a narrow tag-specific bypass, not a universal bypass of shields, wards, or all defences.
- **Fearless does not resist all Soul effects:** only the Fear tag triggers Fearless.
- **Force pushes targets into hazards:** the reward is positional exposure to an existing hazard, not a free bonus multiplier.

**Revise / test before acceptance**

- **Poise limits repeated interruption:** keep Poise separate from health. Set stagger thresholds, recovery, boss resistance, and whether Force and Static share a poise budget.
- **Mucus constrains Dodge:** only when the target is adhered or the dodge path crosses a sticky zone; never disable Dodge globally.
- **Mucus extends Fire exposure:** test only as a capped increase to exposure/Burn buildup, not a direct multiplier to Burn tick damage. Preserve escape and cleanse windows.
- **Shield vs Soul:** split physical projectiles carrying a Soul payload from direct essence-targeting effects. Test whether the shield blocks the carrier; use a specialised Soul Ward for explicit essence resistance.

**Reject as a general rule**

- **Acid + Fire automatic explosion:** reject an unconditional explosion from every Acid hit, puddle, or coating. The current proposed pair reaction, **Premature Evaporation**, is narrower: Fire hits an Acid-coated target, consumes that coating, and creates one brief close-range burst. It is a specific triggered interaction, not proof that Acid is inherently flammable, and remains proposed until playtested.

### Provisional priority order

1. Lock down the damage-component tags and defensive-layer rules.
2. Add Cleanse/Purge, Insulation, Soul Ward, and Regeneration only if they solve demonstrated coverage gaps.
3. Resolve Shield delivery rules and persistent hazards.
4. Test the Mucus + Dodge interaction for control-lock risk. Keep Mucus + Fire as a separate proposed pair reaction (**Flammable Mucus**: Fire consumes a visible Mucus patch into a short-lived burning zone); test its readability and area denial during playtests.
5. Only then tune numerical damage, buildup, duration, and resistance values.