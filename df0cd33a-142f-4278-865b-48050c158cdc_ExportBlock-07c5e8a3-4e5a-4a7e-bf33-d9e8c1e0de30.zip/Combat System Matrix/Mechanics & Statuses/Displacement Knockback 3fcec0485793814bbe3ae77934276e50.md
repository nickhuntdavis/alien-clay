# Displacement / Knockback

Counterplay: Squishy may reduce physical impact and impulse; Membrane reduces knockback while active; heavy Force can knock a Shell layer loose. Mass, anchoring, and terrain matter.
Damage Types: Force
Design Status: Proposed
Effect: Pushes or launches the target according to impact strength and resistance; collision payoffs occur only on actual collision.
Kind: Movement
Role: Changes position through applied physical momentum.
Trigger: A qualifying Force impact connects.