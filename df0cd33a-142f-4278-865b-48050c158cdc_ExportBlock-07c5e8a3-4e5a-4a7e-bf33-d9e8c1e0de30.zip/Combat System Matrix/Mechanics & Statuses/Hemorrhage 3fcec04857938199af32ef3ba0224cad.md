# Hemorrhage

Counterplay: Cap stacks and define refresh/termination. Physical wound damage may be mitigated by physical defences, but Bleed ticks are not automatically reduced by Squishy or Shell. Bloodless blocks only blood-dependent components.
Damage Types: Blood
Design Status: Proposed
Effect: Applies a defined Bleed duration and damage profile; a named finisher may consume the wound for one payoff.
Kind: Status Effect
Role: Turns a qualifying wound into capped ongoing blood loss.
Trigger: A qualifying wound or Blood effect applies Bleed.