# Exsanguination

Counterplay: Not a reward on every Blood tick. Prevent repeat-hit farming; Bloodless blocks extraction only where usable blood is required and does not negate all Blood damage.
Damage Types: Blood
Design Status: Proposed
Effect: Grants a small, capped health/resource benefit.
Kind: Resource Mechanic
Role: Turns a specific wound or Blood attack into limited extraction or sustain.
Trigger: A named attack hits a valid target or consumes a defined wound/bleed threshold.