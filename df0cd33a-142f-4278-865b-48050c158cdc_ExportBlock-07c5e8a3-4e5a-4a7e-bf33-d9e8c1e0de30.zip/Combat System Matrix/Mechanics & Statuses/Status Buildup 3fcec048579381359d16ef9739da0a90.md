# Status Buildup

Counterplay: Keep buildup and decay readable; cap stacks and avoid hidden multi-step recipes. A missed application does not apply its attached status, while existing statuses and hazards persist.
Damage Types: Shared
Design Status: Proposed
Effect: At a defined threshold, applies or upgrades one specified status.
Kind: Damage Mechanic
Role: Tracks progress toward a clearly defined status threshold.
Trigger: Repeated qualifying hits or continued exposure from an explicitly tagged source.