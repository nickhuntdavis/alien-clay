# Poise Damage

Counterplay: Define threshold and recovery; elites and bosses may resist. Avoid stun-lock and avoid treating every Static hit as a guaranteed interrupt.
Damage Types: Force, Static
Design Status: Proposed
Effect: Builds toward a brief stagger or interruption, separate from health damage.
Kind: Damage Mechanic
Role: Pressures an enemy's ability to maintain a stance or action.
Trigger: Qualifying Force impact or a Static hit with an explicit poise/interrupt component connects.