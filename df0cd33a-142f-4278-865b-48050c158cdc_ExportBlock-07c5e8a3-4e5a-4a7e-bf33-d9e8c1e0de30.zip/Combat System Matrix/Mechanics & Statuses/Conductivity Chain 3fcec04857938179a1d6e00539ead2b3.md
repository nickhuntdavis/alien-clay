# Conductivity / Chain

Counterplay: Use a visible chain budget and conductivity requirements. A pool reaction is bounded to its visible area and one pulse; do not duplicate Fire propagation.
Damage Types: Static
Design Status: Proposed
Effect: An arc jumps to a limited number of valid targets, or one pulse travels through a defined conductive pool.
Kind: Damage Mechanic
Role: Rewards conductive links and clustered positioning with limited electrical chaining.
Trigger: Static hits an eligible target or explicitly conductive path.