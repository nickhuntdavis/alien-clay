# Shell Corrosion

Counterplay: Make layer loss visible. Do not treat corrosion as universal defence bypass or as an automatic way to stop Membrane regeneration.
Damage Types: Acid
Design Status: Proposed
Effect: Corrosion erodes or removes Shell layers. Lost layers do not regenerate during the encounter.
Kind: Damage Mechanic
Role: Erodes finite Shell layers so later qualifying hits can reach the creature more effectively.
Trigger: Acid hits or sustained, explicitly corrosive exposure against a Shell-protected target.