# Essence Drain

Counterplay: Do not invent a resource for every enemy. Soul does not automatically bypass Shell or Membrane; bypass requires an explicit essence-targeting tag.
Damage Types: Soul
Design Status: Proposed
Effect: Reduces the specified essence/spiritual resource, distinct from ordinary health damage.
Kind: Resource Mechanic
Role: Targets a defined nonphysical resource where one exists.
Trigger: An explicitly essence-targeting Soul component connects with a valid target.