# Force + Soul — Soul Purpose

Confidence: Low
Design Status: Proposed
Limits / Exceptions: No fragment or pickup system. Exposure is brief and must be visually signalled.
Relationship: Conversion
Result: The hit breaks the mark and briefly exposes the target to the next Soul hit.
Source: Force + Soul
Target: Soul-marked enemy
Trigger / Conditions: A Force hit connects with a visibly Soul-marked target.