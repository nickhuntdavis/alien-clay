# Membrane resists Force impact

Confidence: Medium
Design Status: Accepted
Limits / Exceptions: Measurable resistance, not immunity. Resolve the physical hit and impulse separately; do not make Membrane a blanket status shield.
Relationship: Counter
Result: Force drains the shield less efficiently and causes less knockback while the shield remains active.
Source: Membrane
Target: Force
Trigger / Conditions: A qualifying Force hit strikes a target while its Membrane is active.