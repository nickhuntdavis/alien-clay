# Force + Static — Shocking Impact

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: Requires the named combo, not merely two unrelated hits on the same target. No chain reaction.
Relationship: Synergy
Result: A short local electrical burst occurs around the impact.
Source: Force + Static
Target: Impact point
Trigger / Conditions: A named Force/Static weapon combo lands.