# Force + Fire — Flashover

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: One jump only; no uncontrolled propagation chain. Distinct from pushing an enemy into an existing hazard.
Relationship: Amplification
Result: A small tongue of flame jumps to one nearby eligible target.
Source: Force + Fire
Target: Burning target and one nearby enemy
Trigger / Conditions: A Force weapon hits a burning target.