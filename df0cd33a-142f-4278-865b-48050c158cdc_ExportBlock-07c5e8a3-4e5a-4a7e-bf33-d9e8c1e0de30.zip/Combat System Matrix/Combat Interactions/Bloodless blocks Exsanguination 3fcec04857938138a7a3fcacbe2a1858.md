# Bloodless blocks Exsanguination

Confidence: High
Defences: Bloodless (../Defences%20&%20Traits/Bloodless%203fcec04857938187b021e684cd372fd9.md)
Design Status: Proposed
Limits / Exceptions: Do not silently convert this into immunity to all Blood damage.
Mechanics: Exsanguination (../Mechanics%20&%20Statuses/Exsanguination%203fcec048579381a1aba3ccaa81d14db1.md)
Relationship: Immunity
Result: Extraction and blood-resource gain are prevented unless an alternate resource rule exists.
Source: Blood
Target: Bloodless
Trigger / Conditions: An ability attempts to extract usable blood.