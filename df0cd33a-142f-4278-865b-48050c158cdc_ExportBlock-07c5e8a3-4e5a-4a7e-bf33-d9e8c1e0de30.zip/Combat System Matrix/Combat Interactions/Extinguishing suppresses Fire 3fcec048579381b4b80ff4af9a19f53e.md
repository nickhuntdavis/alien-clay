# Extinguishing suppresses Fire

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: Do not introduce a Water damage type or assume every environment has an extinguishing mechanic. Special Fire effects require explicit rules.
Mechanics: Burn (../Mechanics%20&%20Statuses/Burn%203fcec048579381e1b3c3c29d54b0989d.md), Propagation (../Mechanics%20&%20Statuses/Propagation%203fcec048579381128ec5fba870300f22.md)
Relationship: Counter
Result: A successful, explicitly supported extinguishing action reduces Burn exposure or stops further propagation.
Source: Environmental extinguishing
Target: Burn / Propagation
Trigger / Conditions: A specific extinguishing action or authored environmental counter successfully affects a burning target or zone.