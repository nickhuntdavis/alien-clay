# Force + Mucus — Snot Rocket

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: One payoff only: no extra stun or bonus-damage layer. Landing patch has a clear boundary and short lifetime.
Relationship: Conversion
Result: The enemy launches in the hit direction and leaves one small sticky patch on landing.
Source: Force + Mucus
Target: Mucus-stuck enemy
Trigger / Conditions: A Force attack hits a Mucus-stuck enemy.