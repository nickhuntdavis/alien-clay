# Static + Soul — Interference Pattern

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: No general interrupt against every Soul enemy or every Soul hit. Respect the attack's interrupt window and poise rules.
Relationship: Counter
Result: The Soul attack is interrupted.
Source: Static + Soul
Target: Telegraphed Soul attack
Trigger / Conditions: A Static combo hits during a clearly telegraphed Soul attack.