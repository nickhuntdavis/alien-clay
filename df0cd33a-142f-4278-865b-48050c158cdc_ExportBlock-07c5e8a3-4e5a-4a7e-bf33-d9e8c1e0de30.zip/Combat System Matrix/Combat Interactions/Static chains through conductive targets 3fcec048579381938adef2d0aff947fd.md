# Static chains through conductive targets

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: Use chain budgets and conductivity requirements; avoid unrestricted jumps.
Mechanics: Conductivity / Chain (../Mechanics%20&%20Statuses/Conductivity%20Chain%203fcec04857938179a1d6e00539ead2b3.md), Interruption (../Mechanics%20&%20Statuses/Interruption%203fcec0485793812a9260d1e83d1519cf.md)
Relationship: Amplification
Result: Static can chain damage or interruption across a limited number of targets.
Source: Static
Target: Clustered conductive targets
Trigger / Conditions: Valid conductive paths connect multiple targets.