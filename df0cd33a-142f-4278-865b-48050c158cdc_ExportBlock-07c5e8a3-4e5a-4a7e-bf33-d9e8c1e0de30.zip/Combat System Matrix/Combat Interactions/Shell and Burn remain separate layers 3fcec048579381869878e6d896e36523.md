# Shell and Burn remain separate layers

Confidence: Medium
Defences: Shell (../Defences%20&%20Traits/Shell%203fcec0485793817a9c73d6a5543d5a89.md)
Design Status: Accepted
Limits / Exceptions: Resolve the physical hit component separately from Burn application and later burning-zone exposure. Do not add blanket status immunity.
Mechanics: Burn (../Mechanics%20&%20Statuses/Burn%203fcec048579381e1b3c3c29d54b0989d.md)
Relationship: Neutral / No Special Interaction
Result: Shell reduces qualifying physical components but does not inherently resist heat or Burn.
Source: Fire
Target: Shell
Trigger / Conditions: A Fire attack applies direct damage and/or Burn to a Shell-protected target.