# Mucus + Blood — Caught in the Clot

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: The patch catches once and then is consumed or disabled. Blood must be visibly present; no long immobilisation.
Relationship: Conversion
Result: The first enemy crossing the patch is briefly caught.
Source: Mucus + Blood
Target: Clot patch
Trigger / Conditions: A named Mucus/Blood combo creates a visibly blood-laced clot patch.