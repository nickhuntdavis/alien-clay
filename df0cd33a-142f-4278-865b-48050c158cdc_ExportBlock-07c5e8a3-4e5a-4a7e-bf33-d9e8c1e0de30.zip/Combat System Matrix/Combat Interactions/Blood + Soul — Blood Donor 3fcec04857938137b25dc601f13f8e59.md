# Blood + Soul — Blood Donor

Confidence: Low
Design Status: Proposed
Limits / Exceptions: Cap the heal and prevent repeat-hit farming. No new resource meter; do not heal on every Blood tick.
Relationship: Synergy
Result: The player restores a small fixed amount of health.
Source: Blood + Soul
Target: Soul-marked target
Trigger / Conditions: A Blood attack hits a visibly Soul-marked target.