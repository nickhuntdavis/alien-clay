# Acid + Mucus — Slick Move

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: Convert rather than layer hazards. Show the new boundary and expiry; do not leave the old sticky effect underneath.
Relationship: Conversion
Result: The Mucus patch is replaced by a short-lived corrosive slick.
Source: Acid + Mucus
Target: Mucus patch
Trigger / Conditions: An Acid attack hits a visible Mucus patch.