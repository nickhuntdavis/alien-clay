# Ignition propagates to susceptible targets

Confidence: Medium
Design Status: Accepted
Limits / Exceptions: Fire may propagate only on Ignition to susceptible targets or surfaces within a defined range. Each target can trigger at most one propagation event per chain; use a re-ignition lockout to prevent loops.
Mechanics: Ignition (../Mechanics%20&%20Statuses/Ignition%203fcec0485793812e8cd9c474f381ad4f.md), Propagation (../Mechanics%20&%20Statuses/Propagation%203fcec048579381128ec5fba870300f22.md)
Relationship: Amplification
Result: Nearby targets or surfaces may ignite, creating conditional area pressure.
Source: Fire
Target: Nearby flammable targets
Trigger / Conditions: Ignition occurs near a susceptible target within propagation range.