# Thorns retaliate once on contact

Confidence: High
Design Status: Accepted
Limits / Exceptions: Thorns does not mitigate the incoming hit and triggers once per hit, not once per damage component. Ranged attacks, remote hazards, non-contact effects, and cleanly Dodged attacks do not trigger it.
Relationship: Counter
Result: Thorns returns damage once for that attack hit.
Source: Thorns
Target: Qualifying melee/contact attacks
Trigger / Conditions: A qualifying melee/contact attack connects with a Thorns-protected target.