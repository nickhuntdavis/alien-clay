# Static + Blood — Blood Circuit

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: Select one target only; do not pulse across the whole pool or chain onward.
Relationship: Synergy
Result: One arc hits the nearest eligible enemy standing in or beside the pool.
Source: Static + Blood
Target: Visible blood pool and nearby enemy
Trigger / Conditions: A Static attack hits a visible blood pool.