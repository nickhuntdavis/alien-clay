# Fearless resists Fear only

Confidence: High
Defences: Fearless (../Defences%20&%20Traits/Fearless%203fcec048579381188052e733bca9f94e.md)
Design Status: Accepted
Limits / Exceptions: Fearless does not resist all Soul damage, essence drain, Silence, or other effects that lack the Fear tag.
Mechanics: Fear (../Mechanics%20&%20Statuses/Fear%203fcec0485793812b82d2c28243628bb1.md)
Relationship: Immunity
Result: Fear buildup, duration, or severity is reduced or prevented according to the trait's tier.
Source: Fear
Target: Fearless
Trigger / Conditions: A Fear-tagged effect attempts to apply to a Fearless target.