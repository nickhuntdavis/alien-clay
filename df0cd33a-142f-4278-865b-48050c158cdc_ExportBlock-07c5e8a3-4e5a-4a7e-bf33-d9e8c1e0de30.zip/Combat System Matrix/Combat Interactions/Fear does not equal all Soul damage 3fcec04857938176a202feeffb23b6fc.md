# Fear does not equal all Soul damage

Confidence: High
Defences: Fearless (../Defences%20&%20Traits/Fearless%203fcec048579381188052e733bca9f94e.md)
Design Status: Proposed
Limits / Exceptions: Prevents a broad trait from accidentally countering an entire damage type.
Mechanics: Fear (../Mechanics%20&%20Statuses/Fear%203fcec0485793812b82d2c28243628bb1.md), Essence Drain (../Mechanics%20&%20Statuses/Essence%20Drain%203fcec0485793813abb6ef0e41fd3a140.md)
Relationship: Neutral / No Special Interaction
Result: Fearless provides no benefit unless the effect carries the Fear tag.
Source: Fearless
Target: Soul damage
Trigger / Conditions: A Soul attack deals damage or drains essence without applying Fear.