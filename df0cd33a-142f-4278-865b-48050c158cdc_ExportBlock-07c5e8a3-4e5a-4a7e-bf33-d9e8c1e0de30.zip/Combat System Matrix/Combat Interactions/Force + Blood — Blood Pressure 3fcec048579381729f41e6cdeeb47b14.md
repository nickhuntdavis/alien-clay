# Force + Blood — Blood Pressure

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: Do not add another Bleed stack or create a large pool.
Relationship: Amplification
Result: The existing wound bursts for one small area hit.
Source: Force + Blood
Target: Bleeding enemy
Trigger / Conditions: A Force finisher hits a bleeding target.