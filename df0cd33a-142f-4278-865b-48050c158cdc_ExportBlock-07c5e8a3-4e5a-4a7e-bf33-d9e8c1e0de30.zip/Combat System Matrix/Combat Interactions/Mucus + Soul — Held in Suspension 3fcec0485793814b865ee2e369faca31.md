# Mucus + Soul — Held in Suspension

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: The visible mark is the trigger. Keep the pin short and avoid adding extra damage or another status.
Relationship: Synergy
Result: The target is briefly pinned in place.
Source: Mucus + Soul
Target: Soul-marked enemy
Trigger / Conditions: A Mucus attack hits a visibly Soul-marked target.