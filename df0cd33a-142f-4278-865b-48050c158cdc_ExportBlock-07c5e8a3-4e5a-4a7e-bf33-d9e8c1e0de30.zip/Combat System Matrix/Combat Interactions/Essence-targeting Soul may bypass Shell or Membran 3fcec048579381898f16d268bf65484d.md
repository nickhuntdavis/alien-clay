# Essence-targeting Soul may bypass Shell or Membrane

Confidence: Medium
Defences: Shell (../Defences%20&%20Traits/Shell%203fcec0485793817a9c73d6a5543d5a89.md)
Design Status: Accepted
Limits / Exceptions: Soul damage does not automatically bypass defences by type label alone. Special wards and explicit shield rules may still apply.
Mechanics: Soul Fracture (../Mechanics%20&%20Statuses/Soul%20Fracture%203fcec048579381b48643f27442f267c4.md), Essence Drain (../Mechanics%20&%20Statuses/Essence%20Drain%203fcec0485793813abb6ef0e41fd3a140.md)
Relationship: Bypass
Result: Only the explicitly essence-targeting component may bypass the named physical defence.
Source: Soul
Target: Shell / Membrane
Trigger / Conditions: An attack component explicitly tagged as targeting essence hits a target protected by Shell or Membrane.