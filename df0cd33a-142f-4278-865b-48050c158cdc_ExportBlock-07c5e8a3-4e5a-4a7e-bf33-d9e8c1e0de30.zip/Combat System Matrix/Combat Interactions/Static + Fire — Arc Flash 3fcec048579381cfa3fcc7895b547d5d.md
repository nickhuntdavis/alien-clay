# Static + Fire — Arc Flash

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: One arc only. Do not stack extra Burn, stun, and multi-jump chaining into one reaction.
Relationship: Amplification
Result: One short arc jumps to the nearest other eligible enemy.
Source: Static + Fire
Target: Burning target and one nearby enemy
Trigger / Conditions: A Static attack hits a burning target.