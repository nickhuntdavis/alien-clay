# Acid + Soul — Soul Erosion

Confidence: Low
Design Status: Proposed
Limits / Exceptions: Do not invent a new defence/resource for the reaction. One clear outcome per target; the fallback is a brief mark refresh.
Relationship: Conversion
Result: The reaction consumes the mark to weaken an explicit Soul ward; if the target has no such ward, refresh the mark briefly instead.
Source: Acid + Soul
Target: Soul-marked enemy
Trigger / Conditions: An Acid combo hits a visibly Soul-marked target.