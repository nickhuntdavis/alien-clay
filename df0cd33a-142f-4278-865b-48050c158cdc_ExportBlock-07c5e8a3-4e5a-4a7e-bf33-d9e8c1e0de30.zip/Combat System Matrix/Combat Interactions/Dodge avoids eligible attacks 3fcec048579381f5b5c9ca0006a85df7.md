# Dodge avoids eligible attacks

Confidence: High
Defences: Dodge (../Defences%20&%20Traits/Dodge%203fcec048579381cfad4aff313aa4e951.md)
Design Status: Accepted
Limits / Exceptions: AoE edges may still hit; Dodge does not remove existing statuses or persistent hazards. Each attack defines its own hitbox/coverage rules.
Relationship: Counter
Result: A clean miss prevents the hit and its attached effects.
Source: Dodge
Target: Eligible avoidable attacks
Trigger / Conditions: Timing and positioning move the defender outside the attack's actual hitbox under its tracking rules.