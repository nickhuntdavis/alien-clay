# Mucus constrains Dodge routes

Confidence: Medium
Defences: Dodge (../Defences%20&%20Traits/Dodge%203fcec048579381cfad4aff313aa4e951.md)
Design Status: Testing
Limits / Exceptions: Must not globally disable Dodge. Existing coating/patches are not cleared by dodging.
Mechanics: Adhesion (../Mechanics%20&%20Statuses/Adhesion%203fcec048579381a0b4d3c99f614da452.md)
Relationship: Counter
Result: Movement options may be reduced or dodge distance shortened while crossing a sticky zone or while Adhered.
Source: Mucus
Target: Movement / Dodge
Trigger / Conditions: A dodge path crosses a sticky surface or an Adhered target tries to move.