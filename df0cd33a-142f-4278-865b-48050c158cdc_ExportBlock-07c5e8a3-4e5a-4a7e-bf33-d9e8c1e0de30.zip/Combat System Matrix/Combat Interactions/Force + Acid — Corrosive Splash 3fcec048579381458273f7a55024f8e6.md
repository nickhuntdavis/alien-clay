# Force + Acid — Corrosive Splash

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: Requires a visible Acid coating. Keep the splash small and bounded; it must not trigger another splash recursively.
Relationship: Synergy
Result: A small splash spreads Acid to nearby enemies, spreading the setup rather than adding a large second burst.
Source: Force + Acid
Target: Acid-coated target and nearby enemies
Trigger / Conditions: A Force strike hits a target visibly coated in Acid.