# Membrane interaction with Soul effects

Confidence: Medium
Defences: Membrane (../Defences%20&%20Traits/Membrane%203fcec0485793814f9689c7a17131a663.md)
Design Status: Accepted
Limits / Exceptions: Soul damage does not bypass the shield by type label alone. Do not imply every Soul ability phases through barriers.
Mechanics: Essence Drain (../Mechanics%20&%20Statuses/Essence%20Drain%203fcec0485793813abb6ef0e41fd3a140.md), Soul Fracture (../Mechanics%20&%20Statuses/Soul%20Fracture%203fcec048579381b48643f27442f267c4.md)
Relationship: Bypass
Result: Eligible direct Soul damage is absorbed normally. Only an explicitly essence-targeting component may bypass Membrane when the attack is tagged for that exception.
Source: Soul
Target: Membrane
Trigger / Conditions: A Soul attack meets an active Membrane.