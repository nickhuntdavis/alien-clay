# Poise limits repeated interruption

Confidence: Medium
Design Status: Testing
Limits / Exceptions: Keep poise separate from health; build pressure toward stagger. Define thresholds, recovery, boss resistance, and whether Force and Static use the same poise budget.
Mechanics: Poise Damage (../Mechanics%20&%20Statuses/Poise%20Damage%203fcec04857938149b7eaea752384fe8a.md), Interruption (../Mechanics%20&%20Statuses/Interruption%203fcec0485793812a9260d1e83d1519cf.md)
Relationship: Counter
Result: Interruption occurs only after a threshold or against a vulnerable action.
Source: Force / Static
Target: Heavy actions and resistant targets
Trigger / Conditions: Repeated impacts or Static hits build poise pressure.