# Membrane absorbs eligible direct damage

Confidence: Medium
Defences: Membrane (../Defences%20&%20Traits/Membrane%203fcec0485793814f9689c7a17131a663.md)
Design Status: Accepted
Limits / Exceptions: Statuses are prevented only if the applying delivery hit is blocked under that attack's rule. Existing statuses and persistent hazards remain. Membrane regenerates after a short no-shield-damage period.
Relationship: Counter
Result: The shield pool absorbs eligible direct damage before health until depleted.
Source: Membrane
Target: Eligible direct attacks
Trigger / Conditions: An eligible direct-damage component hits an active Membrane.