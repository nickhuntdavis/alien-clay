# Acid + Fire — Premature Evaporation

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: The reaction consumes the target coating; Acid pools do not automatically explode. Keep the burst modest and prevent retriggering from the same coating.
Mechanics: Shell Corrosion (../Mechanics%20&%20Statuses/Shell%20Corrosion%203fcec0485793811087a9d9c2a0cfc26c.md), Combustion (../Mechanics%20&%20Statuses/Combustion%203fcec0485793814fac22d61a5705a8d0.md)
Relationship: Conversion
Result: The Acid coating is consumed in a modest close-range burst.
Source: Acid + Fire
Target: Acid-coated target
Trigger / Conditions: A Fire attack hits a target that visibly carries Acid coating.