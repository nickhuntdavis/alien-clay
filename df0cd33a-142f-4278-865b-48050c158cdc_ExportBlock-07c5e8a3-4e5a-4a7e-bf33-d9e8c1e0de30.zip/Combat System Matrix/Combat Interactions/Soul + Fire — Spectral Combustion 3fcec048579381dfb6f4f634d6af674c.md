# Soul + Fire — Spectral Combustion

Confidence: Low
Design Status: Proposed
Limits / Exceptions: Trigger on a hit, not only on defeat. One burst only; do not add an unbounded Fire propagation chain.
Relationship: Conversion
Result: The mark is consumed in a short spectral burst.
Source: Soul + Fire
Target: Burning, Soul-marked enemy
Trigger / Conditions: A named Soul/Fire combo hits a burning target that also has a visible Soul Mark.