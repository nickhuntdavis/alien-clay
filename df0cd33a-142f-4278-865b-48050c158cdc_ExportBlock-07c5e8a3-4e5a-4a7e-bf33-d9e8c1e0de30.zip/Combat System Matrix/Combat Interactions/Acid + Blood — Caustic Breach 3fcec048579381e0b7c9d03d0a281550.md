# Acid + Blood — Caustic Breach

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: Defence erosion only: no extra damage-over-time and no new wound stack. Make the erosion visible.
Relationship: Amplification
Result: The hit strips more Armour/Shell effectiveness than Acid alone.
Source: Acid + Blood
Target: Bleeding enemy
Trigger / Conditions: A named Acid combo hits a bleeding target.