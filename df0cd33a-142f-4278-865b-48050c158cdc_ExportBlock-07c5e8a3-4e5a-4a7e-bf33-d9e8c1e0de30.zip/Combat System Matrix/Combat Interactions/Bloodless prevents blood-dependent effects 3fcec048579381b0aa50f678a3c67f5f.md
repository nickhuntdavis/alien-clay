# Bloodless prevents blood-dependent effects

Confidence: High
Defences: Bloodless (../Defences%20&%20Traits/Bloodless%203fcec04857938187b021e684cd372fd9.md)
Design Status: Accepted
Limits / Exceptions: Does not prevent direct Blood-type damage or non-bleeding wound effects by default.
Mechanics: Hemorrhage (../Mechanics%20&%20Statuses/Hemorrhage%203fcec04857938199af32ef3ba0224cad.md)
Relationship: Immunity
Result: The blood-dependent Bleed or extraction component fails or uses an explicitly designed alternate effect.
Source: Blood
Target: Bloodless
Trigger / Conditions: A Blood effect requires blood loss, bleeding, or usable blood extraction.