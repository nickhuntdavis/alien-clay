# Heavy Force can shed a Shell layer

Confidence: Medium
Design Status: Accepted
Limits / Exceptions: Requires the heavy-hit threshold and a clear visual layer-loss cue. Lost layers do not regenerate during the encounter.
Relationship: Counter
Result: One Shell layer is knocked loose, reducing protection for later qualifying hits.
Source: Force
Target: Shell
Trigger / Conditions: A sufficiently heavy Force impact hits a Shell-protected target.