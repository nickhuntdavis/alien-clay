# Mucus + Fire — Flammable Mucus

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: The patch is consumed after one short burn. No lingering Mucus slow after ignition; reaction-created fire cannot retrigger itself.
Mechanics: Adhesion (../Mechanics%20&%20Statuses/Adhesion%203fcec048579381a0b4d3c99f614da452.md), Burn (../Mechanics%20&%20Statuses/Burn%203fcec048579381e1b3c3c29d54b0989d.md), Ignition (../Mechanics%20&%20Statuses/Ignition%203fcec0485793812e8cd9c474f381ad4f.md)
Relationship: Conversion
Result: The patch burns briefly as a small temporary no-go zone, then is consumed.
Source: Mucus + Fire
Target: Visible Mucus patch
Trigger / Conditions: A Fire attack ignites a visible Mucus patch.