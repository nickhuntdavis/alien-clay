# Force drives targets into hazards

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: Requires an actual hazard and valid path; no automatic bonus damage in empty terrain.
Mechanics: Displacement / Knockback (../Mechanics%20&%20Statuses/Displacement%20Knockback%203fcec0485793814bbe3ae77934276e50.md), Burn (../Mechanics%20&%20Statuses/Burn%203fcec048579381e1b3c3c29d54b0989d.md), Combustion (../Mechanics%20&%20Statuses/Combustion%203fcec0485793814fac22d61a5705a8d0.md)
Relationship: Synergy
Result: Positioning converts Force displacement into extra exposure or conditional ignition.
Source: Force + Fire
Target: Burning zone / flammable terrain
Trigger / Conditions: Knockback pushes a target into a persistent flame or flammable hazard.