# Blood + Fire — Cauterise

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: The burst should compensate for ending the Bleed. Do not apply a fresh Burn by default.
Relationship: Conversion
Result: The existing Bleed is consumed for one immediate burst.
Source: Blood + Fire
Target: Bleeding enemy
Trigger / Conditions: A Fire attack hits a bleeding target.