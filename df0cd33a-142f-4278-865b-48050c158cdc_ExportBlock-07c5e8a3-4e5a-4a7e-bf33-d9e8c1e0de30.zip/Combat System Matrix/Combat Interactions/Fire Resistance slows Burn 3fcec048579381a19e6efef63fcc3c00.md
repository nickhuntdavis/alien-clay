# Fire Resistance slows Burn

Confidence: Medium
Defences: Fire Resistance (../Defences%20&%20Traits/Fire%20Resistance%203fcec0485793810691dde6aa78085b15.md)
Design Status: Accepted
Limits / Exceptions: Reduced buildup, reduced ticks, delayed Ignition, and full immunity are separate parameters. Fire Resistance does not inherently reduce physical impact.
Mechanics: Burn (../Mechanics%20&%20Statuses/Burn%203fcec048579381e1b3c3c29d54b0989d.md), Ignition (../Mechanics%20&%20Statuses/Ignition%203fcec0485793812e8cd9c474f381ad4f.md), Status Buildup (../Mechanics%20&%20Statuses/Status%20Buildup%203fcec048579381359d16ef9739da0a90.md)
Relationship: Counter
Result: Burn buildup or Burn damage is reduced; Ignition may be delayed only if separately defined.
Source: Fire
Target: Fire Resistance
Trigger / Conditions: Fire attempts to apply Burn buildup or Burn damage to a resistant target.