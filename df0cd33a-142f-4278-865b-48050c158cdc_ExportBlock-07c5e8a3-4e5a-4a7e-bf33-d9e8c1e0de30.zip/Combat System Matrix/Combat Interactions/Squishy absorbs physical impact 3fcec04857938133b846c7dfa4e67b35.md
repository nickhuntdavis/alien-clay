# Squishy absorbs physical impact

Confidence: Medium
Defences: Squishy / Absorption (../Defences%20&%20Traits/Squishy%20Absorption%203fcec048579381d4bc09ec56d660cc2c.md)
Design Status: Accepted
Limits / Exceptions: This is not immunity. Keep proportional reduction distinct from Shell's fixed reduction per layer; it grants no blanket status resistance.
Mechanics: Displacement / Knockback (../Mechanics%20&%20Statuses/Displacement%20Knockback%203fcec0485793814bbe3ae77934276e50.md)
Relationship: Counter
Result: Qualifying physical damage is proportionally reduced and physical impulse/knockback may also be reduced.
Source: Force
Target: Squishy / Absorption
Trigger / Conditions: A qualifying physical Force hit or impulse affects a Squishy-protected target.