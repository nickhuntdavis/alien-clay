# Static recharges or supercharges Membrane

Confidence: Medium
Design Status: Accepted
Limits / Exceptions: Bound the benefit and show it clearly. Repeated hits must not create an infinite recharge loop.
Relationship: Amplification
Result: The Membrane rapidly recharges or briefly supercharges, with a visible cue.
Source: Static
Target: Membrane
Trigger / Conditions: A defined Static hit or named Static interaction affects an active Membrane.