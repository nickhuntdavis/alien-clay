# Acid + Static — Conductive Pool

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: The pulse stays within the visible pool boundary and occurs once; no repeated pulses or infinite chain.
Relationship: Synergy
Result: One electrical pulse travels across the puddle.
Source: Acid + Static
Target: Visible Acid puddle
Trigger / Conditions: A Static attack hits a visible Acid puddle.