# Acid erodes Shell

Confidence: Medium
Defences: Shell (../Defences%20&%20Traits/Shell%203fcec0485793817a9c73d6a5543d5a89.md)
Design Status: Accepted
Limits / Exceptions: Shell layers do not regenerate during the encounter. Show each layer loss. Acid does not automatically stop Membrane regeneration or bypass all defences.
Mechanics: Shell Corrosion (../Mechanics%20&%20Statuses/Shell%20Corrosion%203fcec0485793811087a9d9c2a0cfc26c.md)
Relationship: Suppression
Result: Corrosion erodes or removes finite Shell layers, improving later qualifying hits.
Source: Acid
Target: Shell
Trigger / Conditions: Acid hits or sustained explicitly corrosive exposure affects a Shell-protected target.