# Static + Mucus — Sticky Situation

Confidence: Medium
Design Status: Proposed
Limits / Exceptions: One trigger per patch, with a clear charge cue and expiry. No repeated shocks from the same patch.
Relationship: Synergy
Result: The next enemy entering the patch is briefly shocked.
Source: Static + Mucus
Target: Charged Mucus patch
Trigger / Conditions: A Static attack charges a visible Mucus patch.