# Fire Resistance

Category: Status Resistance
Design Status: Proposed
Does Not Automatically Protect Against: Does not inherently reduce the physical component of a Fire attack, smoke, environmental hazards, or Fire pair reactions.
Limits / Counterplay: Keep Burn resistance separate from heat-impact mitigation. Clearly signal resistance and distinguish reduced buildup, reduced ticks, delayed Ignition, and immunity.
Method: Reduces Burn buildup or Burn damage; delaying Ignition is a separate parameter and full immunity is a stronger explicit trait.
Protects Against: Damage Over Time, Status Buildup