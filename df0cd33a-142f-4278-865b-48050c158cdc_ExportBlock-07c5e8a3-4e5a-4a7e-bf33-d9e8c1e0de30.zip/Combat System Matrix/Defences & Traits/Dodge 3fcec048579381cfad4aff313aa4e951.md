# Dodge

Category: Attack Avoidance
Design Status: Accepted
Does Not Automatically Protect Against: Does not reduce damage after a hit, clear existing statuses, or erase persistent hazards. AoE edges may still hit and later contact with a hazard can still apply effects.
Limits / Counterplay: A clean miss prevents the hit and attached effects. Define attack-specific AoE and tracking rules; Mucus constrains movement only when the path crosses a sticky zone or the target is Adhered.
Method: Avoids an attack through movement/timing when positioning beats the hitbox and tracking rules.
Protects Against: Displacement, Impact, Physical Damage