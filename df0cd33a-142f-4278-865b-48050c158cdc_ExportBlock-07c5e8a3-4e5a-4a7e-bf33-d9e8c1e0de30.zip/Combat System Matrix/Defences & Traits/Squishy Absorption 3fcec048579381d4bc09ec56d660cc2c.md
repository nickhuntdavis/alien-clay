# Squishy / Absorption

Category: Force Absorption
Design Status: Accepted
Does Not Automatically Protect Against: Does not grant blanket status resistance or inherently reduce Acid, Static, Soul, heat/Burn, Mucus adhesion, Bleed ticks, or nonphysical effects.
Limits / Counterplay: Force is physical and qualifies. Keep proportional reduction distinct from Shell's fixed per-layer reduction; avoid extra hidden resistance rules.
Method: Proportionally reduces qualifying physical damage and may reduce physical impulse/knockback.
Protects Against: Displacement, Impact, Physical Damage