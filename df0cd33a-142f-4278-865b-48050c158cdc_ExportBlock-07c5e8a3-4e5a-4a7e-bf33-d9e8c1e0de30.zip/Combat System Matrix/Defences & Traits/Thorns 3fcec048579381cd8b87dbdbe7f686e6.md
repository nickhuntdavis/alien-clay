# Thorns

Category: Innate Trait
Design Status: Accepted
Does Not Automatically Protect Against: Does not retaliate against ranged attacks, remote hazards, non-contact effects, or attacks that cleanly miss due to Dodge.
Limits / Counterplay: Resolve one retaliation per attack hit, not per damage component. A successful Dodge prevents contact and therefore prevents retaliation. Bleeding/charged retaliation should be a named variant or weapon-combo effect.
Method: Returns damage once when a qualifying melee/contact hit connects. It does not reduce or prevent the incoming hit.