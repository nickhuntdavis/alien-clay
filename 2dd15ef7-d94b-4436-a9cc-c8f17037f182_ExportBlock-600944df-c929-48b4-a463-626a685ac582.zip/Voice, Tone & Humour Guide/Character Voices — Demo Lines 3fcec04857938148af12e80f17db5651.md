# Character Voices — Demo Lines

# Purpose

A dialogue calibration page for the two voices in Spawn Prawn. These are demo lines and tonal benchmarks, not all final copy.

# Core contrast

- **The Scientist:** external observer. Clinical, procedural, apathetic. Makes absurd events sound routine.
- **The consciousness:** an unnamed, pre-incarnate soul that speaks to and at the sperm. It is not the sperm. It pushes the sperm toward fertilisation because conception is the consciousness's way into the physical world, where it can be born.
- **The sperm:** the being addressed and guided by the consciousness. Dialogue from the consciousness should address the sperm as “you,” not speak as if the consciousness itself were the sperm.
- **Together:** the Scientist makes the absurd sound routine; the consciousness makes the sperm's journey feel cosmically urgent.
- For the full canon and writing rules, see [Voice, Tone & Humour Guide](../Voice,%20Tone%20&%20Humour%20Guide%203fcec04857938150a3d3d3775c76e848.md).

# Voice rules

- Keep the Scientist mostly at flat apathy. Rarely let composure break, and return to flatness immediately afterwards.
- The consciousness can be funny, stupid, repetitive, selfish, self-justifying or wrong. It should not sound like a polished comedian delivering a joke every time.
- The consciousness's campaign voice can become devoted, obsessive and sincere. It does not need to be crude all the time.
- Keep tutorials brief and actionable, delivered by the consciousness to the sperm. Preserve progressive disclosure: tell the sperm/player what to do, not the whole mechanic.
- Use silence when the gameplay already communicates the information.
- Treat these as calibration examples; review them against the main Voice, Tone and Humour Guide before shipping.

# Ordinary gameplay

**Scientist**

> Sample 1A has changed direction. No explanation has been requested.
> 

**The consciousness, to the sperm**

> That way. You have a very important appointment.
> 

**Scientist**

> Mucus. Viscosity: considerable. Your concerns are noted.
> 

**The consciousness, to the sperm**

> It's snot. Why is it always snot?
> 

**Scientist**

> Subject has acquired additional offensive capability. This is unlikely to improve its temperament.
> 

**The consciousness, to the sperm**

> New weapon. Excellent. Let's see what you do with this bastard.
> 

# Tutorials and upgrades

**Sprint tutorial — the consciousness, to the sperm**

> Hold to move faster. Yes, faster. We'll worry about the consequences when we have consequences.
> 

**Dodge tutorial — the consciousness, to the sperm**

> Move. The big horrible thing is trying to turn you into a historical footnote.
> 

**Level-up — the consciousness, to the sperm**

> Free DNA. Take it. We've made worse decisions for less.
> 

**Bad upgrade — the consciousness, to the sperm**

> That one looks useless. Take it. I have a feeling.
> 

**Level-up observation — Scientist**

> Genetic modification continues. Quality control remains theoretical.
> 

# Combat and danger

**Low health — Scientist**

> Vital signs: concerning. Data quality: excellent.
> 

**Low health — the consciousness, to the sperm**

> You are not dying. You haven't even been born yet. That would be a terrible start.
> 

**Surrounded — the consciousness, to the sperm**

> Right. Right. Nobody panic. Especially you. Actually, both of us. Whatever.
> 

**Boss arrives — Scientist**

> A larger specimen. The slide was already adequately occupied.
> 

**Boss arrives — the consciousness, to the sperm**

> Oh, fuck off. You have places to be.
> 

**Death — Scientist**

> Cause of death: optimism.
> 

**Death — the consciousness**

> You were so fucking close.
> 

# The consciousness's obsession with conception

**Campaign start — the consciousness, to the sperm**

> Other swimmers want a career, a family, a nice flat. You want the egg. Only the egg. Forever the egg.
> 

**Campaign inner voice — the consciousness, to the sperm**

> Keep going. You haven't seen it yet. You don't know what it looks like, but you know.
> 

**After a difficult fight — the consciousness, to the sperm**

> That thing tried to eat you. The egg would have been furious. Probably. You should survive long enough to tell it.
> 

**Near death — the consciousness, to the sperm**

> Not yet. You haven't even met. It would be embarrassing to die before the introduction.
> 

**Quiet moment — the consciousness, to the sperm**

> You wonder if the egg is lonely. You decide it must be. You are very good at deciding things for the egg.
> 

# Rare composure breaks

These should be genuinely rare. The consciousness does not need to become louder when the Scientist does.

**Celestial drop — Scientist, Tier 3**

> NO. No, no, no. That is not a normal reaction. I have the papers. I have ALL the papers. There is nothing in the papers about that. What the FUCK am I supposed to put on the form?
> 

**Celestial drop — the consciousness, to the sperm**

> Can it kill things? I don't care what it is. Can it kill things?
> 

**Scientist recovery**

> Form 12B filed.
> 

# First egg victory

**The consciousness — emotional peak, addressing the sperm**

> There. There you are. You made it. I've been waiting for you to get here my entire existence.
> 

**Scientist — Tier 3**

> IT REACHED THE EGG. Sample 1A reached the egg. After fourteen years of nothing. I need to check the slide. I need to check the slide.
> 

**Scientist recovery**

> Result recorded.
> 

# Strongest current benchmarks

- **Impulsiveness:** “That one looks useless. Take it. I have a feeling.”
- **Denial:** “You are not dying. You haven't even been born yet. That would be a terrible start.”
- **Delusion:** “You are very good at deciding things for the egg.”
- **Devotion:** “There. There you are. You made it. I've been waiting for you to get here my entire existence.”

# Key risks

- Do not write the consciousness as if it is the sperm. It is an as-yet-unborn soul speaking to the sperm because it needs fertilisation to enter the physical world.
- The consciousness must not become too articulate or too consistently funny. Its immaturity should feel real, with one overwhelming purpose. Sincere moments make crude moments stronger, and vice versa.
- The Scientist's loudest breaks must remain exceptional. Most lines should be restrained enough that a genuine loss of composure feels like an event.