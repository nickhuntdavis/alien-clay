# Voice, Tone & Humour Guide

# Purpose and status

This is the canonical writing guide for Spawn Prawn's narrative voice, humour, dialogue, and progressive disclosure. It records adopted direction and practical rules for writing new lines. The linked **Character Voices — Demo Lines** page is a working test bench, not a replacement for this guide.

# The game's central comic tension

Spawn Prawn is an Android autorun bullet-storm roguelite. The player steers one sperm cell through a microscopic gauntlet while weapons fire automatically and the immune system tries to destroy it. A sleepless Scientist works alone in a university lab, trying to evolve the “most powerful sperm.”

The game treats microscopic biological horror as both a life-or-death struggle and an ordinary laboratory procedure. The mechanics can be deep, strategic, and scientifically inspired; the narration often treats suffering as a routine result.

**Core contrast:** the Scientist makes the absurd sound routine. The pre-incarnate consciousness makes the routine sound cosmically urgent.

# The three narrative layers

## 1. The Scientist: external observer

The Scientist is a tired, clinical, unreliable observer working alone at night or on weekends. The study is permitted but not respected. There is no audience, staff, committee, or implied group in the room.

He logs events and results. He does not act as a conventional game master, explain the fiction, narrate every visible effect, or tell the player what to feel. His default attitude is procedural apathy. The humour comes from the gap between the severity of what is happening and the banality of how he records it.

He refers to samples by ID, such as **Sample 1A**, not by a vial name. Sample names are selected sperm samples, not pet names for the Scientist's equipment.

### Scientist voice rules

- Default to flat, clinical, procedural apathy.
- Use short, precise sentences and British spelling.
- Prefer understatement, bureaucratic framing, exact numbers, lists, and scientific language.
- Brackets are preferred to em dashes.
- Use “damage type,” “unstable reaction,” “Feat,” and “perform.”
- Never say “element” or “elemental” for damage types; never use “cast” for using an ability.
- Avoid slang, memes, pop-culture references, exclamation marks, and conspicuous punchline-writing.
- He can be aware of the experiment and its stakes, but must not sound aware that he is in a game.
- Do not explain what the player can already see.
- Do not make him warm or empathetic by default. A rare supportive break is more effective because the baseline is cold.
- After a composure break, return immediately to flatness on the next line.

### Scientist humour signatures

1. **Bureaucratic understatement:** describe a catastrophe as a minor procedural issue.
2. **Clinical mismatch:** use precise laboratory language for something viscerally ridiculous.
3. **Over-specificity:** exact numbers, classifications, and forms where no reasonable person would need them.
4. **The list that turns:** begin with routine observations and end on an unexpectedly alarming item.
5. **Real science:** use true scientific details when they make the situation stranger, not as a lecture.
6. **Borrowed disclaimer:** occasionally end a line with a dry, familiar-sounding qualification, such as “98% effective.”
7. **Innocently funny terminology:** use a legitimate clinical word such as “flaccid” without acknowledging its double meaning.
8. **Corrupted phrase:** alter one word in a recognisable sex, contraception, or medical phrase so the new phrase fits the mechanic. “Premature Evangelation” is the kind of construction to test: the mechanic must justify the joke.

The Scientist should never wink at his own jokes.

## 2. The pre-incarnate consciousness: the voice addressing the sperm

**This consciousness is not the sperm.** It speaks to the sperm, pushes it, guides it, cajoles it, pressures it, and sometimes talks at it. It is a soul that has not yet entered the physical dimension. It wants the sperm to fertilise the egg because conception is its way into the world: its chance to be conceived and born.

This is a foundational premise, not a mystery the dialogue must explain or solve. The consciousness may be funny, crude, immature, selfish, frightened, deluded, or unexpectedly sincere. It has one overwhelming purpose: get the sperm to the egg.

Refer to it simply as **the consciousness** in production notes and as the voice speaking to the sperm in dialogue guidance. Do not give it a formal in-world name unless a later design decision explicitly does so. “The Urge” is not the chosen name.

### Consciousness voice rules

- It addresses the sperm as **you**. It is not speaking as “I, the sperm.”
- It is an unseen, not-yet-born soul with a personal stake in fertilisation.
- It should feel like an actual limited consciousness, not a professional comedian performing polished jokes.
- Its gameplay voice is impulsive, blunt, immature, impatient, self-justifying, biologically inappropriate, and occasionally crude.
- It can issue short, direct instructions during play. It wants the sperm to act now, not to understand the full system.
- It may rationalise bad choices, insist on a plan it has just invented, panic while claiming not to panic, or interpret events entirely in terms of the egg.
- It is allowed to be stupid, repetitive, selfish, wrong, or embarrassingly confident.
- Do not make every line a joke. A voice that is funny all the time becomes predictable and tiring.
- Crudeness should be specific and inventive, not generic swearing as wallpaper. Aim crude humour at the situation, not at protected groups or an out-group.
- Its campaign voice can become devoted, obsessive, desperate, and sincere. The soul wants to enter the world; this longing should be emotionally legible even when its reasoning is ridiculous.
- Do not over-explain the metaphysics. The audience does not need a lecture about souls, consciousness, or the physical dimension.
- Do not accidentally collapse the consciousness into the sperm, the player, a tutorial system, or a detached narrator. Its relationship is personal: it needs the sperm to succeed.

### Two registers, one consciousness

**Gameplay register:** immediate, pushy, impulsive, practical, impatient. It reacts to danger and upgrades, urges movement, and offers minimal instructions.

**Campaign register:** more reflective and emotionally exposed. It becomes devoted and obsessive about the egg, sometimes tender, sometimes disturbing, sometimes comically deluded. It can imagine a relationship with someone it has never met.

The registers are not separate characters. Gameplay compresses the voice into urgency; campaign moments reveal the depth and strangeness of its desire.

## 3. Silence and unvoiced systems

Not every mechanic needs a line. HUD information, repeated status effects, ordinary attacks, damage reactions, and visual effects should often remain silent. Dialogue competes with the bullet-storm for attention.

Silence is a deliberate writing choice, not missing content.

# Composure ladder: Scientist only

The Scientist's composure system is a rarity scale, not a set of equally common styles.

- **Tier 0 — Flat apathy (about 90%):** neutral observation, clinical understatement, no emotional flourish.
- **Tier 1 — Dry flicker (about 8%):** a slight crack, unusually pointed phrasing, a brief trace of interest or irritation.
- **Tier 2 — Slipping (about 2%):** disbelief, excitement, support, or frustration is briefly visible.
- **Tier 3 — Full Carl (under 0.5%):** crude, loud, specific, uncontrolled language. Reserved for genuinely extreme events.

The percentages are directional targets for the overall impression, not a requirement to hit an exact quota. Tier 3 must feel earned. It is not the default tone for a rare item merely because the item is rare.

### Scientist break modes

- **Excited:** a result exceeds anything he expected.
- **Supportive:** a surprisingly human reaction slips through, without turning him into a warm companion.
- **Irritated:** the experiment, apparatus, or result is obstructing him.
- **Disbelieving:** the observation contradicts what he thinks is possible.

Escalate in steps when appropriate. Do not jump from neutral to shouting without a strong reason. Recover instantly to Tier 0 on the next line.

The consciousness does not use this Scientist ladder. It can panic, celebrate, or become sincere for its own reasons; its intensity follows its relationship to the sperm and the egg.

# Humour principles

## The gap is the joke

The most reliable source of humour is the collision between:

- microscopic, bodily, disgusting, or sexually charged events; and
- clinical language, bureaucratic procedure, ordinary inconvenience, or an embarrassingly earnest desire.

Do not add a punchline if the contrast already works.

## Keep the humour grounded

- Use real science where it adds surprise or credibility.
- Prefer one strong turn over several stacked jokes.
- Specificity beats generic profanity.
- Let a line begin sincerely and then reveal the speaker's warped priorities.
- Use understatement to make a frightening event funnier, not to erase its stakes.
- Do not force the Scientist and the consciousness to joke about the same thing in the same way. Their different interpretations are the point.
- Do not use references that date quickly, memes, or recognisable pop-culture imitation.
- Avoid explaining the joke after it lands.

## Three reusable signatures

1. **Corrupted phrase:** a familiar phrase is altered by one word, with the new wording grounded in the mechanic.
2. **Borrowed disclaimer:** a dry qualification or familiar disclaimer is appended to an otherwise serious line.
3. **Innocent clinical term:** a legitimate term is funny in context, and the Scientist never acknowledges it.

These are tools, not quotas. Repetition will make them feel like a formula.

# Progressive disclosure and information ownership

The game should reveal only as much as the player needs at that moment.

- **Layer 1 — Name and flavour:** a short, memorable name and a line of flavour. No numbers.
- **Layer 2 — First-time hint:** only when necessary; one short sentence, roughly 12 words. Tell the player what to do, not why the mechanic exists or how all its values work.
- **Layer 3 — Field Guide / codex:** full stats, formulas, reaction rules, science notes, and interactions.

Do not repeat a hint after the player has learned it. Do not explain an effect that is already visible. Exceptions: irreversible losses, controls that cannot reasonably be discovered, and important hidden information.

## Screen and content ownership

- **Menus:** Scientist at Tier 0.
- **Tutorials and first sightings:** the consciousness gives a short, direct, skippable instruction when needed. Name and flavour first; no lecture.
- **Loot and upgrade cards:** name plus flavour. Show only the bare stat change needed to make a choice legible. The consciousness may push or rationalise; do not explain every synergy.
- **Weapons, Feats, trophies, mutations:** name can carry the joke; description states the visible effect. Avoid numbers and synergy exposition unless needed.
- **Enemy first-sighting cards:** Scientist can identify or clinically frame the specimen; avoid over-explaining what is on screen.
- **In-run commentary:** sparse. The consciousness reacts to immediate pressure; Scientist observations should be rare and purposeful.
- **Damage types:** plain, clinical names. Reaction names may carry the joke. Keep the full reaction chart in the Field Guide.
- **HUD and repeated status effects:** mostly silent. Never repeat the same informational line throughout a run.
- **Boss intro:** Scientist stays flat. A kill can reach Tier 2; a first kill may justify Tier 3 if it is genuinely exceptional.
- **Death screen:** Scientist stays at Tier 0. The consciousness may show denial, anger, or the pain of being denied entry into the world.
- **First egg victory:** the consciousness gets the emotional peak; the Scientist may have an exceptional first-time break. Later wins should be more restrained.
- **Campaign:** the consciousness carries its own emotional arc. Keep this distinct from Scientist observations.
- **Field Guide:** thorough, precise, mechanically complete, and allowed to explain.
- **Errors and system messages:** plain and useful. No joke when clarity matters.

# Scientist sample identity and letter drift

Sample names follow a strain/run convention:

- First sample: **1A — Baseline**.
- Another run of the same strain: **1B — Baseline**.
- A newly unlocked strain might be **2A — Bright Spark**.
- The number identifies the strain; the letter identifies the run of that strain.
- After 1Z, continue with 1AA unless a later implementation decision changes the sequence.

Across repeated runs of the same strain, the Scientist may become incrementally more invested. This appears only through small event lines; he never announces that he has grown attached. When the strain number changes, he resets to cold procedural distance. This drift is subtle and never overrides the baseline voice.

# Campaign emotional arc of the consciousness

The consciousness's objective is absolute: fertilisation is how it can be conceived and born into the physical world. Its longing is both absurd and sincere.

Possible progression:

1. **Certainty:** it assumes the egg is the only thing that matters.
2. **Rationalisation:** it invents reasons, expectations, and imagined facts about the egg.
3. **Investment:** it begins to treat survival as necessary because there is someone it must reach.
4. **Desperation:** near-death moments reveal how much it fears being denied existence.
5. **Recognition:** reaching the egg is emotionally enormous because it represents entry into the world, not just winning a level.

Do not force this arc into every run or explain it in exposition. Let events and small details carry it. Silence and brevity can make the rare sincere line more powerful.

# Benchmark lines and intended effect

These are calibration examples, not guaranteed final shipping copy.

## Scientist: flat, dry, clinical

- “Cause of death: optimism.”
- “Vital signs: concerning. Data quality: excellent.”
- “The immune system is winning. The immune system always thinks it is winning.”
- “Time has been rewound. Biology has filed a formal complaint.”
- “Subject expired in wave N of 20. Promising. Get me another one.”
- “It is not a phase. It is a pH.”
- “It is not a crit. It is being believed.”

The Scientist should not acknowledge these as jokes. Their tone should sound like a tired person recording results.

## The consciousness: gameplay urgency

- “Move. The big horrible thing is trying to turn you into a historical footnote.”
- “That one looks useless. Take it. We have made worse decisions for less.”
- “Right. Nobody panic. Especially you. Actually, both of us. Whatever.”
- “You are not dying. You have not even been born yet. That would be a terrible start.”
- “Keep moving. The egg is not going to come looking for you.”

These lines address the sperm. Avoid first-person claims that make the speaker sound like the sperm itself.

## The consciousness: devotion, delusion, sincerity

- “Other swimmers want a career, a family, a nice flat. You want the egg. Only the egg. Forever the egg.”
- “Keep going. You haven't seen it yet. You don't know what it looks like, but you know.”
- “You wonder if the egg is lonely. You decide it must be. You are very good at deciding things for the egg.”
- “Not yet. You haven't even met. It would be embarrassing to die before the introduction.”
- “There. There you are. You have been coming for it your entire life.”

The last line is deliberately phrased from the consciousness's perspective toward the sperm. Keep the emotional truth; do not confuse who is speaking.

## Scientist: rare break

- “NO. No, no, no. That is not a normal reaction. I have the papers. I have ALL the papers. There is nothing in the papers about that. What the FUCK am I supposed to put on the form?”
- Recovery: “Form 12B filed.”

The recovery is flat. The contrast is essential.

# Quality-control checklist for every new line

Before approving dialogue, ask:

1. **Who is speaking?** Scientist, consciousness addressing the sperm, campaign narration, or no one?
2. **Is the consciousness speaking to the sperm rather than as the sperm?** Check pronouns, perspective, and implied identity.
3. **Does this belong on this screen?** Do not put codex detail into a loot card or tutorial.
4. **Does the line add information, character, humour, or emotional meaning?** If none, cut it.
5. **Can the player already see it?** If yes, consider silence.
6. **Is the joke built from contrast or specificity?** Remove generic quips and piled-on punchlines.
7. **Is the Scientist's composure break rare enough?** Keep most lines at Tier 0.
8. **Does the consciousness sound impulsive rather than polished?** Let it be wrong, repetitive, or irrational.
9. **Does the line preserve the soul's motive?** It wants the sperm to reach the egg so it can be conceived and born.
10. **Can the line be shorter?** Prefer the smallest line that does the job.

# Related page

[Character Voices — Demo Lines](Voice,%20Tone%20&%20Humour%20Guide/Character%20Voices%20%E2%80%94%20Demo%20Lines%203fcec04857938148af12e80f17db5651.md)

[Character Voices — Demo Lines](Voice,%20Tone%20&%20Humour%20Guide/Character%20Voices%20%E2%80%94%20Demo%20Lines%203fcec04857938148af12e80f17db5651.md)