## 2026-10-21 E-ink UI theme
- Systems: style, uikit
- Files: eink.css (new), fonts/Barlow-*.ttf + OFL.txt (new), style.css, index.html, ARCHITECTURE.md
- What: Every DOM screen and the HUD now use the Figma e-ink design system: grey paper, 2px ink rules, square corners, Barlow, no glow, shadow, gradient or grain; selected and primary invert to ink. Dark mode (Ink, AMOLED black with soft grey text) follows the phone setting. The HUD over the slide is translucent paper with thin rules. style.css's hardcoded greys now point at the colour tokens, so both modes read. The game canvas is unchanged.
- Save data: none.
- Hooks: index.html loads eink.css after style.css.
- Risk: visual only. Icons on paper are darkened with a CSS filter (type colours stay recognisable). Barlow falls back to Roboto until web/fonts is loaded (Barlow TTFs bundled, about 530 KB).
