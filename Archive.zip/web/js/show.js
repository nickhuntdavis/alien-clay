'use strict';
// Spawn Prawn - the Experiment: a sardonic lab tech narrating, achievements with (occasionally real)
// rewards, and lab funding (G.show.viewers, internally) with research grants at funding milestones.
// In the campaign the same meter is your devotion to the egg, and the narrator is your inner voice.

function newShow() {
  return { viewers: 1200, peak: 1200, lastKillT: 0, milestone: 0, idleT: 50, lowHpCd: 0, achieved: {}, order: [], msgQ: [] };
}

function fmtViewers(v) { return (v >= 1e6 ? (v / 1e6).toFixed(1) + 'M' : v >= 1e3 ? (v / 1e3).toFixed(1) + 'K' : Math.round(v) + ''); }
// What the meter is called: the lab's funding, or (in the campaign) your devotion to the egg.
const showWord = () => lvOn() ? 'Devotion' : 'Data';

function sysMsg(head, body, color, force, who) { // who: 'sci' (the Scientist) or 'con' (inner voice) picks the box's look
  if (!G) return;
  const q = G.show.msgQ;
  if (!force && q.length >= 1) return;
  // Chatter (anything not forced) at most every 12s, so the narrator doesn't crowd the slide.
  if (!force) { if (G.t < (G.show.quietT || 0)) return; G.show.quietT = G.t + 12; }
  q.push({ head: narratorHead(head), body, color: color || '#8dffc0', who });
  if (q.length > 6) q.shift();
}
// In the campaign the default narrator gives way to your own inner voice (LONGING_LINES).
const sysPool = kind => (lvOn() && SET.narrator === 'system' && LONGING_LINES[kind]) || SYSTEM_LINES[kind];
function sysLine(kind, force) { if (typeof vxSysLine === 'function' && vxSysLine(kind)) return; const L = sysPool(kind); if (L) sysMsg('SYSTEM MESSAGE', pick(L), '#8dffc0', force, L === SYSTEM_LINES[kind] ? 'sci' : 'con'); }

function addViewers(n) {
  if (!G) return;
  const s = G.show;
  s.viewers += n * G.P.viewers;
  if (s.viewers > s.peak) s.peak = s.viewers;
  while (s.milestone < VIEWER_MILESTONES.length && s.viewers >= VIEWER_MILESTONES[s.milestone]) sponsorGift(VIEWER_MILESTONES[s.milestone++]);
  if (s.viewers >= 1e6) achieve('viewers1m');
}

function sponsorGift(milestone) {
  const sponsor = pick(SPONSORS), type = pick(['heal', 'rage', 'shield', 'magnet', 'chest', 'nuke', 'chest']);
  const p = me(), a = Math.random() * TAU;
  G.pickups.push(makePickup(type, p.x + Math.cos(a) * 70, p.y + Math.sin(a) * 70, { t: 'sponsor', name: lvOn() ? 'the egg' : sponsor }));
  if (lvOn()) sysMsg('A SIGN FROM THE EGG', `Devotion ${fmtViewers(milestone)}. The egg is calling, and we are sure it has sent us a ${POWERUPS[type].name}. Who else would?`, '#ffb400', true, 'con');
  else sysMsg('LAB NOTE', `${fmtViewers(milestone)} data points. Found a ${POWERUPS[type].name} in ${sponsor}. Adding it to the slide. Do not ask what it was doing there.`, '#ffb400', true, 'sci');
  if (!lvOn()) achieve('sponsor');
}

function achieve(id) {
  if (!G) return;
  const s = G.show, A = ACHIEVEMENTS[id];
  if (!A || s.achieved[id]) return;
  s.achieved[id] = true;
  s.order.push(id);
  let reward;
  switch (A.reward) {
    case 'box': G.lootQueue.push({ kind: 'chest', src: { t: 'ach', name: A.name } }); reward = 'Reward: a Gold strand of Donor DNA.'; break;
    case 'myth': G.lootQueue.push({ kind: 'myth', src: { t: 'ach', name: A.name } }); reward = 'Reward: ACHIEVEMENT DNA. Every card in it is Mythical or Immaculate.'; break;
    case 'bossbox': G.lootQueue.push({ kind: 'boss', src: { t: 'ach', name: A.name } }); reward = 'Reward: a Gold strand of Boss DNA.'; break;
    case 'reroll': G.rerolls++; reward = 'Reward: +1 reroll token.'; break;
    case 'scrap': G.scrap += 40; reward = 'Reward: 40 scrap. Try not to spend it all at once.'; break;
    case 'heal': healPlayer(G.P.maxHp * 0.3, true); reward = 'Reward: 30% health. Use it responsibly.'; break;
    default: reward = pick(NO_REWARD);
  }
  sysMsg('NEW ACHIEVEMENT!', `${A.name}. ${A.desc} ${reward}`, '#ffd23f', true);
  addViewers(1000);
  sfx('level');
}

function onShowKill(e, src) {
  const s = G.show;
  s.lastKillT = G.t;
  addViewers((e.boss ? 25000 : e.elite ? 150 : 4) * (1 + G.t / 300));
  if (G.kills === 1) achieve('firstblood');
  else if (G.kills === 100) achieve('kills100');
  else if (G.kills === 1000) achieve('kills1000');
  else if (G.kills === 5000) achieve('kills5000');
  if (src.last) achieve('lastword');
  if (src.prequel) achieve('spoilers');
  if (src.echo) achieve('echokill');
  if (src.friendly) achieve('friendly');
  if (e === G.grudge) { if (src.grudge) { achieve('grudge'); sysLine('grudge'); } G.grudge = null; }
  if (e.boss) { achieve('boss'); if (G.bossHits0 != null && Object.values(G.stats.hurtKind).reduce((x, y) => x + y, 0) <= G.bossHits0 + 0.01) achieve('flawless'); }
}

function updateShow(dt) {
  const s = G.show, p = me();
  if (G.t - s.lastKillT > 4) s.viewers = Math.max(500, s.viewers * (1 - 0.02 * dt));
  s.idleT -= dt;
  if (s.idleT <= 0) { s.idleT = rand(45, 75); sysLine('idle'); }
  s.lowHpCd -= dt;
  if (p.hp < G.P.maxHp * 0.25 && s.lowHpCd <= 0) { s.lowHpCd = 40; sysLine('lowhp'); }
  if (G.t >= 300) achieve('survive5');
  if (G.t >= 600) achieve('survive10');
}
