'use strict';
// Spawn Prawn - rival champions and the sperm count. Five other swimmers grow stronger elsewhere on the
// map. They farm the immune system and pick fights when they feel big. The sperm count falls as the race
// goes on; when it reaches the last six (you and five), the Final Five showdown starts. Win it and the
// count is 1: swim into the egg and break its membrane (game.js openEgg). A rival that reaches EGG.level
// before the Final Five goes for the egg itself (rivalEgg): stop it before it breaks in.
// Rivals arrive one at a time (rivalArrive). In a race, one comes with each scripted wave (waveEvent), at the
// level it reached racing elsewhere. In wave mode (the Petri Dish) a new one joins each ordinary wave from
// wave 2 (rivalWaveJoin, at most RIVAL.dishMax alive); they don't stop a wave being cleared, they keep out of
// it between waves and in boss waves, and any that survive a wave come back stronger (rivalWaveEnd). No sperm count or egg there.
// Hooks: rivalArrive (waveEvent, game.js), rivalWaveJoin (campBegin), rivalWaveEnd (waveClear).

// A rival's level follows its own clock, which runs at its skill (plus a little for every kill it steals).
function rivalLevelAt(clock) { return Math.min(EGG.level, 1 + Math.floor((EGG.level - 1) * Math.pow(Math.max(0, clock) / RIVAL.finish, RIVAL.pow) + 1e-9)); }

// Each run draws five of the twenty rivals (G.rivalSet, chosen at the start of the run).
function runRivals() {
  if (!G.rivalSet) G.rivalSet = shuffle(RIVALS.slice()).slice(0, 5);
  return G.rivalSet;
}
function initRivals() {
  G.rivalsInit = true;
  G.rivalOut = {}; // id -> how they were eliminated
  G.rivalMsgT = 0; G.rivalCullT = 200; G.rivalCulls = 0;
  G.rivalIn = 0; // how many of the set have arrived
  if (G.wave && !G.rivalSet) G.rivalSet = shuffle(RIVALS.slice()); // (the dish can meet any of them, one a wave)
  runRivals();
}
// The level a rival's clock gives, turned round: the clock that reaches level L.
const rivalClockFor = L => RIVAL.finish * Math.pow(Math.max(0, L - 1) / (EGG.level - 1), 1 / RIVAL.pow);
// The next rival in the set swims in, out of sight. Returns it (null once they are all in).
function rivalArrive() {
  if (!G.rivalOut || G.showdown) return null; // (no race set up: campaign levels, the Lab Bench)
  const set = runRivals();
  if ((G.rivalIn || 0) >= set.length) return null;
  G.rivalIn = G.rivalIn || 0;
  const R = set[G.rivalIn++], p = me();
  let x, y;
  if (G.wave) ({ x, y } = dishSpawnPos());
  else { // round the egg at the usual distance, on the side away from you
    const c = G.core, a0 = Math.atan2(c.y - p.y, c.x - p.x);
    let best = -1;
    for (let i = 0; i < 8; i++) { const a = a0 + rand(-1.2, 1.2), qx = c.x + Math.cos(a) * RIVAL.spawnR, qy = c.y + Math.sin(a) * RIVAL.spawnR, d = Math.hypot(qx - p.x, qy - p.y); if (d > best) { best = d; x = qx; y = qy; } }
  }
  const e = makeRival(R, x, y);
  // A race rival has been growing elsewhere all along; a dish rival starts a little behind you.
  e.clock = G.wave ? rivalClockFor(Math.max(1, G.level - 1)) : G.t * R.skill;
  e.lvl = Math.max(1, rivalLevelAt(e.clock)); e.maxHp = 0; rivalStats(e, 1);
  G.enemies.push(e);
  if (G.wave) sysMsg('THE SCIENTIST', `"Another subject for the dish: ${R.name}. Let us see which of you is fitter."`, R.color, true);
  else rivalNews(e, `${R.name} has joined the race (LV ${e.lvl}).`, true);
  return e;
}
// Wave mode, an ordinary wave from wave 2: a new rival drops in soon after the splash.
function rivalWaveJoin(V) {
  if (V.n < 2 || isBossWave(V.n)) return;
  if (G.enemies.filter(e => e.rival && !e.dead).length >= RIVAL.dishMax) return;
  after(2.5, () => { if (G.wave && G.wave.active) rivalArrive(); });
}
// Wave mode, a wave beaten: every rival still alive heals up and comes back stronger.
function rivalWaveEnd(V) {
  if (!G.rivalsInit) return;
  for (const e of G.enemies) {
    if (!e.rival || e.dead) continue;
    e.clock = Math.max(e.clock, rivalClockFor(Math.min(EGG.level, e.lvl + RIVAL.dishGrow)));
    e.lvl = Math.max(e.lvl, rivalLevelAt(e.clock)); rivalStats(e, 1);
    rivalNews(e, `${e.name} survived the wave and came back stronger (LV ${e.lvl}).`, true);
  }
}

function makeRival(R, x, y) {
  const def = { id: 'rival', name: R.name, hp: 1, speed: RIVAL.speed, armour: 2, r: 15, dmg: 10, xp: 0, color: R.color, shape: 'sperm', ai: 'rival', patterns: [] };
  const e = makeEnemy(def, x, y);
  Object.assign(e, { rival: true, rid: R.id, R, lvl: 1, clock: 0, mode: 'roam', wx: x, wy: y, modeT: 0, zapT: 1, calmT: 0, lastHp: 0, shootCd: 2 });
  e.maxHp = 0; rivalStats(e, 1);
  return e;
}

// Recompute a rival's body from its level. heal: fraction of max HP restored on top.
// Toughness tracks your recent damage output, so a rival your size is always a proper duel
// (about RIVAL.duel seconds of your full firepower); smaller rivals fold faster.
function rivalStats(e, heal) {
  const L = e.lvl, t = PT();
  const rel = Math.pow(Math.min(1.5, L / Math.max(1, G.level)), 1.5);
  const M = rivalMod(e);
  const maxHp = (RIVAL.hpBase * hpMul(t) * (1 + L / 7) + (G.dpsAvg || 0) * RIVAL.duel * rel) * (e.final ? 1.4 : 1) * (M.hp || 1) * (1 + VET.big * vetK()) * (G.wave ? RIVAL.dishHp : 1); // the Final Five are built to last; dish rivals are lighter (one of many things in a wave)
  const k = e.maxHp > 0 ? e.hp / e.maxHp : 1;
  e.maxHp = maxHp;
  e.hp = Math.min(maxHp, maxHp * Math.min(1, k + heal));
  e.armour = 2 + Math.floor(L / 8) + (M.armour || 0);
  e.r = (14 + L * 0.28) * (M.r || 1);
  e.speed = RIVAL.speed * (1 + L / 90) * (M.speed || 1);
  e.dmg = 10 * dmgMul(t) * (1 + L / 40) * (G.wave ? RIVAL.dishHit : 1) * (V10 ? V10_DIFF.rival : 1); // (v10: boss10.js)
  e.lastHp = e.hp;
}

// A rival's body against the standard one (their personality, data.js RIVALS). Stand-ins have none.
const rivalMod = e => (e.R && e.R.mod) || {};
// Traits (data.js RIVALS mod): regen, ranged, tantrum, blink, barge, revive, sprint, magpie, sniper, spread,
// cloak, escort, leech, slime, plus body numbers (hp, speed, r, contact, armour, zapN, zapR).
const rivalHas = (e, k) => !!(e.R && e.R.mod && e.R.mod[k]);

function rivalGrow(e, dt) {
  if (e.lvl >= EGG.level) return;
  e.clock += dt * e.R.skill * (G.wave ? RIVAL.dishPace : 1);
  const L = rivalLevelAt(e.clock);
  if (L <= e.lvl) return;
  const before = e.lvl;
  e.lvl = L;
  rivalStats(e, 0.25);
  if (e.vis) { ring(e.x, e.y, e.r + 18, e.color, 0.45, 3); floatText(e.x, e.y - e.r - 20, 'LV ' + L, e.color, 15, 1); }
  // Overtaking you is news. So are round numbers.
  if (before <= G.level && L > G.level) rivalNews(e, `${e.name} has overtaken you (LV ${L}).`, true);
  else if (Math.floor(L / 10) > Math.floor(before / 10)) rivalNews(e, fill(pick(SYSTEM_LINES.rivalLevel), e, L));
}
// A rival at the egg opens the membrane and chips at it (RIVAL.eggDps of it a second, but not while you are
// shooting it). If it gets through, it fertilises the egg and your race is over.
function rivalEgg(e, dt) {
  if (G.state !== 'play') return;
  if (!G.eggE || G.eggE.dead) openEgg(e); else announceEgg(e);
  const m = G.eggE;
  if (e.calmT > 0) return; // (being shot: it stops gnawing to cope)
  if (m.chipF !== G.frameN) { m.chipF = G.frameN; m.hp -= m.maxHp * RIVAL.eggDps * dt; } // (two rivals at the egg don't gnaw twice as fast)
  if (Math.random() < dt * 4) spawnPart(G.core.x + (e.x - G.core.x) * 0.8, G.core.y + (e.y - G.core.y) * 0.8, '#ffd6e8', 2, 90, 0.4);
  if (m.hp > 0) return;
  m.hp = 0; G.rivalWinner = e.name; G.stats.lastHit = e.name; G.lastHitEnt = e;
  banner(e.name.toUpperCase() + ' FERTILISED THE EGG', PAL.danger);
  gameOver();
}
function fill(s, e, l, k) { return s.replace(/\{n\}/g, e.name).replace(/\{l\}/g, l).replace(/\{k\}/g, k || ''); }
function rivalNews(e, text, force) {
  if (!force && G.rivalMsgT > G.realT) return;
  G.rivalMsgT = G.realT + 12;
  sysMsg(G.wave ? 'RIVAL UPDATE' : 'RACE UPDATE', text, e.color, force);
}

function rivalAI(e, dt) {
  if (G.rivalOut[e.rid]) { e.dead = true; return; } // eliminated in a timeline you rewound past
  const p = me();
  const dx = p.x - e.x, dy = p.y - e.y, dist = Math.hypot(dx, dy) || 1;
  e.vis = dist < 900;
  rivalGrow(e, dt);
  // Regenerate after a few quiet seconds.
  const steve = rivalHas(e, 'regen');
  if (e.hp < e.lastHp - 0.5) e.calmT = steve ? 2 : 4; // Second Wind
  e.calmT -= dt;
  if (e.calmT <= 0 && e.hp < e.maxHp && !e.final) e.hp = Math.min(e.maxHp, e.hp + e.maxHp * (steve ? 0.04 : 0.02) * dt);
  e.lastHp = e.hp;
  if (e.frozen > 0) { rivalMove(e, 0, 0, 0, dt); return; }
  if (rivalBarge(e, dx, dy, dist, dt)) return;
  e.modeT -= dt;
  let tx = e.wx, ty = e.wy, spd = e.speed * (G.pill && inPill(e.x, e.y) ? 0.65 : 1);
  const hurt = e.hp < e.maxHp * 0.3;
  const calm = !!(G.wave && (!G.wave.active || G.wave.boss)); // (the dish between waves, and boss waves: they keep to themselves and leave you to the boss)
  if (calm && e.mode === 'hunt') { e.mode = 'roam'; newWaypoint(e); }
  if (!G.wave && !e.final && !G.showdown && e.lvl >= EGG.level && e.mode !== 'egg' && (typeof raceRivalEgg !== 'function' || raceRivalEgg())) { e.mode = 'egg'; rivalNews(e, `${e.name} is LV ${EGG.level} and heading for the egg.`, true); }
  // (rivals only head for the egg from 15:00 in a race: race15.js raceRivalEgg)
  if (e.mode === 'egg' && !e.final) {
    // Breaking in: swim to the egg and gnaw at its membrane. Nothing else matters now.
    const cd = Math.hypot(G.core.x - e.x, G.core.y - e.y) || 1;
    tx = G.core.x - (G.core.x - e.x) / cd * (CORE.r + e.r); ty = G.core.y - (G.core.y - e.y) / cd * (CORE.r + e.r);
    if (cd < CORE.r + e.r + 30) rivalEgg(e, dt);
  } else if (e.final) {
    // The Final Five: no running, no resting, just you.
    // They surround you, one to each side, slowly circling, so no single blast catches them all.
    const a = e.slot + G.t * 0.25, want = 240;
    tx = p.x + Math.cos(a) * want; ty = p.y + Math.sin(a) * want; spd *= 1.15;
  } else if (e.mode === 'flee') {
    tx = e.x - dx / dist * 400; ty = e.y - dy / dist * 400; spd *= 1.35;
    if (e.modeT <= 0 || dist > RIVAL.sight) { e.mode = 'roam'; newWaypoint(e); }
  } else if (e.mode === 'hunt') {
    // Circle you at shooting range.
    const want = rivalHas(e, 'sniper') ? 420 : rivalHas(e, 'ranged') ? 380 : 250, side = e.side;
    tx = p.x - dx / dist * want - dy / dist * 120 * side; ty = p.y - dy / dist * want + dx / dist * 120 * side;
    if (hurt && rivalHas(e, 'tantrum')) { /* Tantrum: too angry to run */ }
    else if (hurt && rivalHas(e, 'blink') && !(e.blinkT > G.t)) rivalBlink(e, dx, dy, dist);
    else if (hurt) { e.mode = 'flee'; e.modeT = 8; rivalNews(e, `${e.name} is running away. Coward. Chase them if you're feeling mean.`); }
    else if (e.modeT <= 0 || dist > RIVAL.sight * 1.3) { e.mode = 'roam'; newWaypoint(e); }
  } else {
    if (Math.hypot(e.wx - e.x, e.wy - e.y) < 60 || e.modeT <= 0) newWaypoint(e);
    // Outgrown by you? They give you a wide berth (you'll have to go and get them).
    if (e.lvl < G.level - 2 && dist < 750) { tx = e.x - dx / dist * 300; ty = e.y - dy / dist * 300; spd *= 1.15; if (Math.hypot(e.wx - p.x, e.wy - p.y) < 900) newWaypoint(e); }
    // Feeling big? Come and have a go.
    if (!calm && dist < RIVAL.sight && !hurt && G.t > RIVAL.huntFrom && e.huntRoll !== Math.floor(G.t / 5)) {
      e.huntRoll = Math.floor(G.t / 5);
      if (Math.random() < e.R.aggro * 0.45 && e.lvl >= G.level - 6) {
        e.mode = 'hunt'; e.modeT = 14 + e.R.aggro * 10;
        rivalNews(e, `${e.name} (LV ${e.lvl}) is coming for you.`);
      }
    }
  }
  spd *= rivalTraits(e, dt, dist);
  const mx = tx - e.x, my = ty - e.y, md = Math.hypot(mx, my);
  rivalMove(e, md > 4 ? mx / md : 0, md > 4 ? my / md : 0, Math.min(spd, md / Math.max(dt, 1e-3)), dt);
  // Contact.
  if (!calm && dist < e.r + p.r && G.state === 'play') hurtPlayer(e.dmg * (rivalMod(e).contact || 1), e.name, e, 'contact');
  // Weapons: zap monsters nearby (stealing your XP), shoot you when you're in range.
  e.zapT -= dt;
  if (e.zapT <= 0) { e.zapT = 0.7; rivalZap(e); }
  e.shootCd -= dt;
  // Early on they mind their own business unless you start something.
  const riled = G.t > RIVAL.huntFrom || e.hp < e.maxHp * 0.95;
  if (!calm && e.shootCd <= 0 && dist < (rivalHas(e, 'sniper') ? 700 : 520) && riled && G.state === 'play') {
    e.shootCd = (e.final ? 1.6 : e.mode === 'hunt' ? 1.1 : 1.8) * (rivalHas(e, 'tantrum') && e.hp < e.maxHp * 0.5 ? 0.5 : 1) * (rivalHas(e, 'sniper') ? 1.7 : 1); // Tantrum; a sniper takes its time
    // Late-game rivals were the deadliest thing on the slide: their fans grow more slowly now and each bullet
    // gains less from the rival's level (about a third less fire at level 50).
    const n = Math.min(e.final ? 4 : 6, 1 + Math.floor(e.lvl / 14)), a0 = Math.atan2(dy, dx), bd = 7 * dmgNow() * (1 + e.lvl / 60) * (e.final ? 1.2 : 1) * (G.wave ? RIVAL.dishHit : 1) * (V10 ? V10_DIFF.rival : 1); // (v10: boss10.js)
    shooterName = e.name; shooterEnt = e;
    if (rivalHas(e, 'sniper')) eBullet(e.x, e.y, a0, 430, bd * 2.4, 6.5, e.color); // one heavy, fast shot
    else { const m = n + (rivalHas(e, 'spread') ? 2 : 0), gap = rivalHas(e, 'spread') ? 0.2 : 0.16; for (let i = 0; i < m; i++) eBullet(e.x, e.y, a0 + (i - (m - 1) / 2) * gap, 210, bd, 5.5, e.color); }
  }
}

function newWaypoint(e) {
  const a = Math.random() * TAU, d = rand(500, CORE.arena - 250);
  e.wx = G.core.x + Math.cos(a) * d; e.wy = G.core.y + Math.sin(a) * d;
  e.modeT = rand(10, 20);
}

function rivalMove(e, ux, uy, spd, dt) {
  const slow = (1 - e.chillAmt) * (e.stasisT > G.realT ? 0.35 : 1) * (G.warp > 0 ? 0.3 : 1);
  e.x += (ux * spd * slow + e.kx * 0.3) * dt; e.y += (uy * spd * slow + e.ky * 0.3) * dt;
  const kd = Math.pow(0.02, dt); e.kx *= kd; e.ky *= kd;
  if (Math.abs(ux) + Math.abs(uy) > 0.1) e.face = Math.atan2(uy, ux);
  pushOut(e, e.r, e.side || 1);
  const c = G.core, ox = e.x - c.x, oy = e.y - c.y, od = Math.hypot(ox, oy) || 1;
  if (od < CORE.r + e.r) { e.x = c.x + ox / od * (CORE.r + e.r); e.y = c.y + oy / od * (CORE.r + e.r); }
  if (od > CORE.arena) { e.x = c.x + ox / od * CORE.arena; e.y = c.y + oy / od * CORE.arena; }
}

// Rivals clear monsters around themselves. Those kills feed them, not you.
function rivalZap(e) {
  let n = 0;
  const M = rivalMod(e), cap = M.zapN || 3;
  forNear(e.x, e.y, RIVAL.zapR * (M.zapR || 1), o => {
    if (o === e || o.rival || o.egg || o.boss || o.charmed || o.dead) return false;
    const d = o.maxHp * (0.25 + e.lvl / 200);
    o.hp -= d; o.flash = 0.07;
    if (e.vis) bolt(e.x, e.y, o.x, o.y, e.color, 0.12);
    if (o.hp <= 0) {
      o.dead = true; e.clock += 0.6;
      if (e.vis) spawnPart(o.x, o.y, o.color, 6, 120, 0.4, 3);
      if (o.def.split) for (let i = 0; i < 2 && G.enemies.length < CAPS.enemies; i++) G.enemies.push(makeEnemy(ENEMIES[o.def.split], o.x + rand(-12, 12), o.y + rand(-12, 12)));
    }
    return ++n >= cap;
  });
}

// The traits that act every frame. Returns a speed multiplier.
function rivalTraits(e, dt, dist) {
  let k = 1;
  const busy = e.mode === 'hunt' || e.final || e.mode === 'flee';
  if (rivalHas(e, 'sprint')) { // bursts of speed every 7s
    e.sprintCd = (e.sprintCd ?? 4) - dt;
    if (e.sprintCd <= 0) { e.sprintCd = 7; e.sprintEnd = G.t + 1.2; if (e.vis) ring(e.x, e.y, e.r * 2, e.color, 0.3, 2); }
    if (e.sprintEnd > G.t) k *= 2.2;
  }
  if (rivalHas(e, 'cloak')) { // fades out of phase: shots pass through it
    e.cloakCd = (e.cloakCd ?? 6) - dt;
    if (e.cloakCd <= 0) { e.cloakCd = 9; e.cloakEnd = G.t + 2; }
    e.phased = e.cloakEnd > G.t;
  }
  if (rivalHas(e, 'magpie') && e.vis) { // hoovers up your XP
    for (const g of G.gems) {
      if (g.dead || g.kind === 's') continue;
      const dx = e.x - g.x, dy = e.y - g.y, d = Math.hypot(dx, dy);
      if (d < 220) { g.x += dx / (d || 1) * 320 * dt; g.y += dy / (d || 1) * 320 * dt; if (d < e.r + 8) { g.dead = true; e.clock += 0.05 * (g.v || 1); } }
    }
  }
  if (rivalHas(e, 'escort') && busy) { // brings friends to a fight
    e.escortCd = (e.escortCd ?? 3) - dt;
    if (e.escortCd <= 0 && G.enemies.length < CAPS.enemies - 10) {
      e.escortCd = 12;
      for (let i = 0; i < 2; i++) G.enemies.push(makeEnemy(ENEMIES.skitter, e.x + rand(-30, 30), e.y + rand(-30, 30)));
      if (e.vis) floatText(e.x, e.y - e.r - 16, 'BACKUP!', e.color, 12, 0.8);
    }
  }
  if (rivalHas(e, 'slime') && busy) { // leaves a sticky acid trail
    e.slimeCd = (e.slimeCd ?? 1) - dt;
    if (e.slimeCd <= 0) { e.slimeCd = 2.2; addHazard(e.x, e.y, 34, 4, e.dmg * 0.4, e.color, e.name + ' slime', 0.35); }
  }
  return k;
}
// From hurtPlayer: a rival with the leech trait heals off the hits it lands on you.
function rivalLeech(ent) {
  if (ent && ent.rival && !ent.dead && rivalHas(ent, 'leech')) { ent.hp = Math.min(ent.maxHp, ent.hp + ent.maxHp * 0.025); if (ent.vis) floatText(ent.x, ent.y - ent.r - 14, '+', ent.color, 12, 0.6); }
}
// Chad's Shoulder Barge: when he is close, he plants himself and glows (0.6s), then charges in a straight
// line. Returns true while it is happening (it replaces his normal movement).
function rivalBarge(e, dx, dy, dist, dt) {
  if (!rivalHas(e, 'barge') || e.frozen > 0) return false;
  e.bargeCd = (e.bargeCd == null ? 3 : e.bargeCd) - dt;
  if (e.bargeWind > 0) {
    e.bargeWind -= dt; e.flash = Math.max(e.flash, 0.04);
    if (e.vis && Math.random() < dt * 8) ring(e.x, e.y, e.r * 1.8, e.color, 0.3, 2);
    if (e.bargeWind <= 0) { e.bargeT = 0.55; e.bargeA = Math.atan2(dy, dx); if (e.vis) sfx('zap'); }
    rivalMove(e, 0, 0, 0, dt); return true;
  }
  if (e.bargeT > 0) {
    e.bargeT -= dt;
    rivalMove(e, Math.cos(e.bargeA), Math.sin(e.bargeA), e.speed * 3.6, dt);
    const p = me();
    if (Math.hypot(p.x - e.x, p.y - e.y) < e.r + p.r && G.state === 'play') { hurtPlayer(e.dmg * 1.5, e.name + ' (Shoulder Barge)', e, 'contact'); e.bargeT = 0; }
    return true;
  }
  if (e.bargeCd <= 0 && dist < 340 && dist > 60 && (e.mode === 'hunt' || e.final) && G.state === 'play') {
    e.bargeCd = e.final ? 6 : 5; e.bargeWind = 0.6;
    if (e.vis) floatText(e.x, e.y - e.r - 18, 'BARGE!', e.color, 14, 0.7);
    return true;
  }
  return false;
}
// Professor Wiggles' Sabbatical: badly hurt, he vanishes and reappears far from you.
function rivalBlink(e, dx, dy, dist) {
  e.blinkT = G.t + 20;
  if (e.vis) { ring(e.x, e.y, e.r * 2.5, e.color, 0.5, 3); spawnPart(e.x, e.y, e.color, 14, 200, 0.5, 3); }
  e.x -= dx / dist * 450; e.y -= dy / dist * 450;
  rivalMove(e, 0, 0, 0, 0.001);
  ring(e.x, e.y, e.r * 2.5, e.color, 0.5, 3);
  e.mode = 'flee'; e.modeT = 6;
  rivalNews(e, `${e.name} has vanished. They'll be back.`);
}
// Kevin's Somehow Fine: the first knockout doesn't take. From killEnemy, before rivalDown.
function rivalSurvives(e) {
  if (!rivalHas(e, 'revive') || e.fine || e.final) return false;
  e.fine = true; e.dead = false; e.hp = e.maxHp * 0.3; e.lastHp = e.hp;
  e.mode = 'flee'; e.modeT = 8;
  ring(e.x, e.y, e.r * 3, e.color, 0.6, 4);
  floatText(e.x, e.y - e.r - 22, e.name.toUpperCase() + ' IS FINE', e.color, 16, 1.4);
  rivalNews(e, `${e.name} is fine. Somehow. Swimming off.`, true);
  return true;
}

// Called from killEnemy when you (or your weapons, echoes and allies) finish off a rival.
function rivalDown(e) {
  e.dead = true;
  G.kills++;
  G.rivalOut[e.rid] = 'you';
  const P = G.P;
  spawnPart(e.x, e.y, e.color, 50, 300, 0.8, 5);
  addDecal(e.x, e.y, e.r * 2.4, e.color);
  cam.shake = 14;
  // Their growth is yours now: about a level of XP, a strand of Donor DNA and a snack.
  const xp = xpNeed(G.level) * 1.2 * (G.wave ? RIVAL.dishXp : 1);
  for (let i = 0; i < 10; i++) dropGem(e.x + rand(-50, 50), e.y + rand(-50, 50), xp / 10);
  G.pickups.push(makePickup('chest', e.x, e.y, { t: 'rival', name: e.name }));
  if (RIVAL_RELICS[e.rid]) G.lootQueue.push({ kind: 'rrelic', rid: e.rid }); // their relic: a choice of two
  healPlayer(P.maxHp * 0.2);
  gainChrono(CHRONO.energyPerCharge * 0.5);
  banner(e.name.toUpperCase() + ' ELIMINATED', e.color);
  sysMsg('SYSTEM MESSAGE', fill(pick(SYSTEM_LINES.rivalDead), e, 0, 'You did that. The lab is taking notes.'), e.color, true);
  addViewers(20000);
  achieve('rivalkill');
  if (!G.wave && runRivals().every(R => G.rivalOut[R.id])) achieve('allrivals');
  sfx('boss'); vibrate(120);
}

const RIVAL_FATES = ['A Macrophage ate them. It did not even chew.', 'They took a wrong turn into a Mucus Wall and are now part of it.',
  'Killer T-Cells got them. Paperwork is being filed.', 'They swam in a very confident circle until they ran out of tail.',
  'Acid got them. They were last seen saying "is it meant to fizz?"'];

// Every tick: the host thins out the field (away from you), and bookkeeping for the race board.
function updateRivals(dt) {
  if (!G.rivalsInit) initRivals();
  const dish = !!(G.wave || G.lvl); // (no culling in the dish or a level, but the code below still tracks your damage)
  // Rolling average of your damage per second (drives rival toughness).
  G.dpsT = (G.dpsT || 0) - dt;
  if (G.dpsT <= 0) {
    G.dpsT = 5;
    let tot = 0; for (const k in G.stats.dmg) tot += G.stats.dmg[k];
    const cur = Math.max(0, tot - (G.dpsLast || 0)) / 5;
    G.dpsLast = tot;
    G.dpsAvg = G.dpsAvg ? G.dpsAvg * 0.8 + cur * 0.2 : cur;
    for (const e of G.enemies) if (e.rival && !e.dead) rivalStats(e, 0);
  }
  if (dish || G.t < G.rivalCullT) return;
  G.rivalCullT = G.t + 75;
  if (G.showdown) return;
  const alive = G.enemies.filter(e => e.rival && !e.dead);
  if (alive.length <= 2 || G.rivalCulls >= 2) return;
  const p = me();
  const pool = alive.filter(e => e.mode !== 'egg' && Math.hypot(e.x - p.x, e.y - p.y) > 1200);
  if (!pool.length || Math.random() > 0.35) return;
  const e = pick(pool);
  e.dead = true; G.rivalOut[e.rid] = 'host'; G.rivalCulls++;
  sysMsg('RACE UPDATE', fill(pick(SYSTEM_LINES.rivalDead), e, 0, pick(RIVAL_FATES)), e.color, true);
}

// Sorted standings for the HUD: you and every rival, alive or not.
function rivalBoard() {
  const rows = [{ name: 'SPERMY', lvl: G.level, color: PAL.you, you: true }];
  for (const R of runRivals().slice(0, G.rivalIn)) { // (only those who have arrived)
    const e = G.enemies.find(o => o.rid === R.id && !o.dead);
    rows.push({ name: R.name, lvl: e ? e.lvl : 0, color: R.color, out: !e, egg: e && e.final, e });
  }
  // Stand-ins who joined the Final Five.
  for (const e of G.enemies) if (e.final && !e.dead && !runRivals().some(R => R.id === e.rid)) rows.push({ name: e.name, lvl: e.lvl, color: e.color, egg: true, e });
  return rows.sort((a, b) => (a.out ? 1 : 0) - (b.out ? 1 : 0) || b.lvl - a.lvl || (a.you ? -1 : 1));
}

// ---------------------------------------------------------------- the sperm count
// About 400 million start the race, and the count doesn't move until you kill something (a monster or one
// of the crowd). From then on it falls with every kill (0.3: monsters, rival swimmers and popped crowd
// sperm), with your growth (0.4, full at level 60) and a little with time (0.3), on a log scale, and never
// goes back up. 95% of that is enough. At the last six (you and five) the Final Five showdown begins;
// each finalist you kill takes one off.
const COUNT = { start: 4e8, time: 540, cull: 9000 * 0.75 }; // (x0.75: there are a quarter fewer monsters to kill) // about a full run's worth of kills, so kills keep counting to the end
function countKill(x, y) {
  if (!G.countStartT && G.countStartT !== 0) { G.countStartT = G.t; }
  G.lastKillX = x; G.lastKillY = y; G.lastKillT = G.realT;
}
function countProgress() {
  if (G.countStartT == null) return 0;
  const cull = G.kills + (G.stats.spermKills || 0) + (G.ambKills || 0) * 0.5;
  const P = 0.3 * Math.min(1, (G.t - G.countStartT) / COUNT.time) + 0.4 * Math.min(1, (G.level - 1) / (EGG.level - 1)) + 0.3 * Math.min(1, cull / COUNT.cull);
  G.countP = Math.max(G.countP || 0, Math.min(1, P / 0.95));
  return G.countP;
}
function spermCount() {
  if (G.fertile) return 1;
  if (G.showdown) return 1 + G.enemies.filter(e => e.final && !e.dead).length;
  const P = countProgress();
  if (P >= 1) return 6;
  return Math.max(7, Math.round(Math.exp(Math.log(COUNT.start) * (1 - P) + Math.log(6) * P)));
}
// Show what your kills are doing to the count: the drop floats up from where you're killing things.
function updateCountFx() {
  const c = spermCount();
  if (G.countShown == null) G.countShown = c;
  if (c < G.countShown) { G.countDrop = (G.countDrop || 0) + (G.countShown - c); G.countShown = c; G.countFlash = 0.25; }
  if (G.countFlash > 0) G.countFlash -= 1 / 60;
  if (G.countDrop > 0 && !(G.countDropT > G.realT) && G.realT - (G.lastKillT || -9) < 0.5 && !G.showdown) {
    G.countDropT = G.realT + 0.35;
    const d = G.countDrop, txt = d >= 1e6 ? (d / 1e6).toFixed(1) + 'M' : d >= 1e3 ? (d / 1e3).toFixed(d >= 1e5 ? 0 : 1) + 'k' : Math.round(d);
    floatText(G.lastKillX, G.lastKillY - 20, '-' + txt, XR.white, 12, 0.8);
    G.countDrop = 0;
  }
}
const FINALIST_NAMES = ['The Dark Horse', 'Anonymous Donor', 'The Favourite', 'Mr Motility', 'The Underdog'];
function startShowdown() {
  while (rivalArrive()) { /* anyone not yet in the race joins the showdown */ }
  G.showdown = { t0: G.t }; G.eggAt = G.t;
  const p = me(), fin = G.enemies.filter(e => e.rival && !e.dead);
  for (let i = fin.length; i < 5; i++) {
    const R = { id: 'fin' + i, name: FINALIST_NAMES[i], color: XR.white, skill: 1, aggro: 1 };
    const e = makeRival(R, p.x, p.y); G.enemies.push(e); fin.push(e);
  }
  fin.forEach((e, i) => {
    // They close in from all sides, fully grown and fully healed.
    const a = i / fin.length * TAU + Math.random() * 0.5;
    e.x = p.x + Math.cos(a) * 850; e.y = p.y + Math.sin(a) * 850;
    e.final = true; e.mode = 'final'; e.slot = i / fin.length * TAU; e.lvl = Math.max(e.lvl, G.level);
    e.maxHp = 0; rivalStats(e, 1);
  });
  banner('THE FINAL FIVE', PAL.danger);
  sysLine('finalFive', true);
  cam.shake = 12; sfx('boss'); vibrate([150, 80, 150]);
}
function updateShowdown() {
  updateCountFx();
  if (!G.showdown && G.state === 'play' && countProgress() >= 1) startShowdown();
  if (G.showdown && !G.fertile && !G.enemies.some(e => e.final && !e.dead)) {
    G.fertile = true;
    banner('SPERM COUNT: 1. BREAK INTO THE EGG!', PAL.reward);
    sysLine('eggReady', true); achieve('eggready');
    sfx('level'); vibrate(200);
  }
  if (typeof raceTick === 'function') raceTick(); // (the egg opens at 15:00: race15.js)
  eggTick(); // (game.js: swim into the egg to start the membrane fight)
}
